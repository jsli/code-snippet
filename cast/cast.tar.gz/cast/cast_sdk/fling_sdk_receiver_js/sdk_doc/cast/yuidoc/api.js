YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "cast.receiver",
        "cast.receiver.CastChannel",
        "cast.receiver.CastMessageBus",
        "cast.receiver.CastReceiverManager",
        "cast.receiver.MediaManager",
        "cast.receiver.logger",
        "cast.receiver.media",
        "cast.receiver.media.MediaInformation",
        "cast.receiver.media.MediaStatus",
        "cast.receiver.media.Volume",
        "cast.receiver.system"
    ],
    "modules": [],
    "allModules": []
} };
});