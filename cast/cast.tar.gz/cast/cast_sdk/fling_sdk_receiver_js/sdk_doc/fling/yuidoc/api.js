YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "fling.receiver",
        "fling.receiver.FlingChannel",
        "fling.receiver.FlingMessageBus",
        "fling.receiver.FlingReceiverManager",
        "fling.receiver.MediaManager",
        "fling.receiver.logger",
        "fling.receiver.media",
        "fling.receiver.media.MediaInformation",
        "fling.receiver.media.MediaStatus",
        "fling.receiver.media.Volume",
        "fling.receiver.system"
    ],
    "modules": [],
    "allModules": []
} };
});