/**
 * @copyright Copyright (C) 2013-2014, Infthink (Beijing) Technology Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @fileOverview This is FLING RECEIVER SDK
 * @author Infthink (Beijing) Technology Co., Ltd.
 * @version 2.0
 */

(function () {
    'use strict';
    Function.prototype.bind = Function.prototype.bind || function (a, b) {
        if (1 < arguments.length) {
            var c = Array.prototype.slice.call(arguments, 1);
            c.unshift(this, a);
            return goog.bind.apply(null, c)
        }
        return goog.bind(this, a)
    };

    /**
     * @name logger
     * @desc The Fling receiver logger object
     * @class It's a instance of cast.receiver.logger
     * @example
     * cast.receiver.logger.setLevelValue(1000)
     */
    var logger = goog.debug.Logger.getLogger("cast");

    /**
     * @name logger.setLevelValue
     * @desc set the log verbosity level.
     * @param {number} value The logging level.
     * @example cast.receiver.logger.setLevelValue(1000)
     * @method logger.setLevelValue
     */
    logger.setLevelValue = function(value){
        logger.setLevel(goog.debug.Logger.Level.getPredefinedLevelByValue(value));
    };
    logger.setLevel(1000);
    console.info("tianye cast receiver....");

    /**
     * @name CastChannel
     * @class Handles cast messages for a specific sender and namespace (it is a point to point communications channel).
     * @desc  It should be used when the application wants to have a virtual connection with a single sender for a specific protocol (namespace), similar to a virtual websocket. Applications should never create CastChannels, they should only be obtained from the corresponding CastMessageBus calling the getCastChannel method. Extends goog.events.EventTarget. Implements EventTarget.
     * @constructor
     * @extends goog.events.EventTarget
     * @param {String} msgBus 所属消息总线
     * @param {String} senderId 发送者标识
     */
    var CastChannel = function (msgBus, senderId) {
        goog.events.EventTarget.call(this);
        this.senderId = senderId;
        this.sockOpened = true;
        this.msgBus = msgBus;
        this.onClose = null;
        this.onMessage = null;

        // 注册消息通道中 senderId 上的消息派发
        goog.events.listen(this.msgBus, this.senderId, this.dispatchMessage, false, this);
    };
    goog.inherits(CastChannel, goog.events.EventTarget);

    /**
     * @name CastChannel.EventType
     * @desc System events dispatched by cast.receiver.CastChannel.
     * @property {string}  MESSAGE Fired when there is a new message.
     * @property {string}  CLOSE Fired when the sender associated with this cast channel has disconnected.
     */
    CastChannel.EventType = {
        MESSAGE: "message",
        CLOSE: "close"
    };

    /**
     * @name CastChannelEvent
     * @constructor
     * @extends goog.events.Event
     * @description Cast channel event
     * @param {String} type event type
     * @param {String} msg message
     * @event
     */
    var CastChannelEvent = function (type, msg) {
        goog.events.Event.call(this, type);
        this.message = msg;
    };
    goog.inherits(CastChannelEvent, goog.events.Event);

    /**
     * @name CastChannel.Event
     * @desc Event raised by the CastChannel.
     * @type {CastChannelEvent}
     * @event
     */
    CastChannel.Event = CastChannelEvent;

    /**
     * @name CastChannel#logger
     * @desc logger of CastChannel
     */
    CastChannel.prototype.logger = goog.debug.Logger.getLogger("cast.receiver.CastChannel");

    /**
     * @name CastChannel#getDebugString
     * @desc get debug string with senderId and messagebus's namespace for CastChannel
     * @method CastChannel#getDebugString
     */
    CastChannel.prototype.getDebugString = function () {
        return "CastChannel[" + this.senderId + " " + this.msgBus.getNamespace() + "]";
    };

    /**
     * @name CastChannel#getNamespace
     * @desc The namespace for this CastChannel.
     * @returns {string} namespace
     * @method CastChannel#getNamespace
     */
    CastChannel.prototype.getNamespace = function () {
        return this.msgBus.getNamespace();
    };

    /**
     * @name CastChannel#getSenderId
     * @desc The senderId for this CastChannel.
     * @returns {String|*}
     * @method CastChannel#getSenderId
     */
    CastChannel.prototype.getSenderId = function () {
        return this.senderId;
    };

    /**
     * @name CastChannel#dispatchMessage
     * @desc 派发事件，将事件包装成 CastChannelEvent 派发到具体的实现类中
     * @param message
     * @method CastChannel#dispatchMessage
     * @private
     */
    CastChannel.prototype.dispatchMessage = function (message) {
        this.logger.finer("Dispatching CastChannel message [" + this.msgBus.getNamespace() + ", " + this.senderId + "]: " + message.data);
        var event = new CastChannelEvent("message", message.data);
        if (this.onMessage) {
            this.onMessage(event);
        }
        this.dispatchEvent(event);
    };

    /**
     * @name CastChannel#close
     * @desc Receiver 主动关闭消息通道，派发通道关闭事件后直接释放本对象
     * @method CastChannel#close
     */
    CastChannel.prototype.close = function () {
        if (this.sockOpened) {
            this.sockOpened = false;
            this.logger.info("Closing CastChannel [" + this.msgBus.getNamespace() + ", " + this.senderId + "]");
            var event = new CastChannelEvent("close", this.senderId);
            if (this.onClose) {
                this.onClose(event);
            }
            this.dispatchEvent(event);
            this.dispose();
        }
    };

    /**
     * @name CastChannel#send
     * @desc Sends a message to the sender associated with this CastChannel.
     * @param message {String} message to send
     * @method CastChannel#send
     */
    CastChannel.prototype.send = function (message) {
        if (!this.sockOpened) {
            throw Error("Invalid state, socket not open");
        }
        this.msgBus.send(this.senderId, message);
    };

    /**
     * @name CastChannel#disposeInternal
     * @desc dispose internal
     * @method CastChannel#disposeInternal
     * @private
     */
    CastChannel.prototype.disposeInternal = function () {
        CastChannel.superClass_.disposeInternal.call(this);
        this.logger.finer("Disposed " + this.getDebugString());
    };

    /**
     * @name IpcChannel
     * @class IpcChannel 系统通讯
     * @constructor
     * @extends goog.events.EventTarget
     * @description IpcChannel 系统通讯
     */
    var IpcChannel = function () {
        goog.events.EventTarget.call(this);
        this.ws = new goog.net.WebSocket(true);
        this.addOnDisposeCallback(goog.partial(goog.dispose, this.ws));
        goog.events.listen(this.ws, goog.net.WebSocket.EventType.OPENED, this.onWsOpen, false, this);
        goog.events.listen(this.ws, goog.net.WebSocket.EventType.CLOSED, this.onWsClose, false, this);
        goog.events.listen(this.ws, goog.net.WebSocket.EventType.ERROR, this.onWsError, false, this);
        goog.events.listen(this.ws, goog.net.WebSocket.EventType.MESSAGE, this.onWsMessage, false, this);
    };
    goog.inherits(IpcChannel, goog.events.EventTarget);

    /**
     * @name SystemEvent
     * @class SystemEvent system event
     * @constructor
     * @extends goog.events.Event
     * @description system event
     * @param type
     * @param senderId
     * @param data
     * @constructor
     * @event
     */
    var SystemEvent = function (type, senderId, data) {
        goog.events.Event.call(this, type);
        this.senderId = senderId;
        this.data = data;
    };
    goog.inherits(SystemEvent, goog.events.Event);

    /**
     * @name IpcChannel#logger
     * @description logger function of IpcChannel
     */
    IpcChannel.prototype.logger = goog.debug.Logger.getLogger("cast.receiver.IpcChannel");

    /**
     * @name IpcChannel#dispatchSystemEvent
     * @description 派发系统事件
     * @param type system type event
     * @method IpcChannel#dispatchSystemEvent
     */
    IpcChannel.prototype.dispatchSystemEvent = function (type) {
        this.logger.fine("IpcChannel " + type);
        this.dispatchEvent(new SystemEvent("urn:x-cast:com.google.cast.system", "SystemSender", JSON.stringify({ type: type })));
    };

    /**
     * @name IpcChannel#onWsOpen
     * @description dispatch websocket opened event
     * @method IpcChannel#onWsOpen
     */
    IpcChannel.prototype.onWsOpen = function () {
        this.dispatchSystemEvent("opened");
    };

    /**
     * @name IpcChannel#onWsClose
     * @description dispatch websocket closed event
     * @method IpcChannel#onWsClose
     */
    IpcChannel.prototype.onWsClose = function () {
        this.dispatchSystemEvent("closed");
    };

    /**
     * @name IpcChannel#onWsError
     * @description dispatch websocket error event
     * @method IpcChannel#onWsError
     */
    IpcChannel.prototype.onWsError = function () {
        this.dispatchSystemEvent("error");
    };

    /**
     * @name IpcChannel#onWsMessage
     * @description dispatch websocket message received event
     * @param wsMsg
     * @method IpcChannel#onWsMessage
     */
    IpcChannel.prototype.onWsMessage = function (wsMsg) {
        this.logger.fine("Received message: " + wsMsg.message);
        var msg = JSON.parse(wsMsg.message);
        var ns = msg && msg.namespace;
        if (msg && ns && msg.senderId && msg.data) {
            this.dispatchEvent(new SystemEvent(ns, msg.senderId, msg.data));
        } else {
            this.logger.severe("IpcChannel Message received is invalid");
        }
    };

    /**
     * @name IpcChannel#open
     * @description 开启 IpcChannel
     * @method IpcChannel#open
     */
    IpcChannel.prototype.open = function () {
        this.logger.info("Opening message bus websocket");
        this.ws.open("ws://localhost:8008/v2/ipc");
    };

    /**
     * @name IpcChannel#close
     * @description close IpcChannel
     * @method IpcChannel#close
     */
    IpcChannel.prototype.close = function () {
        this.logger.info("Closing message bus websocket");
        this.ws.close();
    };

    /**
     * @name IpcChannel#isOpen
     * @description whether websocket is opened
     * @method IpcChannel#isOpen
     */
    IpcChannel.prototype.isOpen = function () {
        return this.ws.isOpen();
    };

    /**
     * @name IpcChannel#send
     * @description send data
     * @param ns
     * @param senderId
     * @param data
     * @method IpcChannel#send
     */
    IpcChannel.prototype.send = function (ns, senderId, data) {
        if (!this.isOpen()) {
            throw Error("Underlying websocket is not open");
        }

        var msg = JSON.stringify({
            namespace: ns,
            senderId: senderId,
            data: data
        });
        this.logger.fine("IPC message sent: " + msg);
        this.ws.send(msg);
    };

    /**
     * @name IpcChannel#disposeInternal
     * @description dispose internal
     * @method IpcChannel#disposeInternal
     * @private
     */
    IpcChannel.prototype.disposeInternal = function () {
        IpcChannel.superClass_.disposeInternal.call(this);
        this.logger.finer("Disposed IpcChannel");
    };

    /**
     * @name CastMessageBus
     * @class Handles cast messages for a specific namespace
     * @desc  Applications should never create a CastMessageBus, they should only be obtained from the cast.receiver.CastReceiverManager instance. Extends goog.events.EventTarget. Implements EventTarget.
     * @param ns {String} namespace
     * @param ipcChannel {String} ipc channel
     * @param c
     * @param messageType {String} message type
     * @constructor
     * @extends goog.events.EventTarget
     */
    var CastMessageBus = function (ns, ipcChannel, c, messageType) {
        goog.events.EventTarget.call(this);
        this.ns = ns;
        this.ipcChannel = ipcChannel;
        this.messageType = messageType || "STRING";
        this.onMessage = null;
        this.channels = {};
        for (var i = 0; i < c.length; i++) {
            this.channels[c[i]] = null;
        }
        goog.events.listen(this.ipcChannel, this.ns, this.dispatchMessage, false, this)
    };
    goog.inherits(CastMessageBus, goog.events.EventTarget);

    /**
     * @name CastMessageBus.MessageType
     * @desc  Message types used by cast.receiver.CastMessageBus.
     * @type {{STRING: string, JSON: string, CUSTOM: string}}
     * @property STRING {string} Messages are CUSTOM-encoded. The application must implement its own cast.receiver.CastMessageBus.prototype.serializeMessage and cast.receiver.CastMessageBus.prototype.deserializeMessage
     * @property JSON {string} Messages are JSON-encoded. The underlying transport will use a JSON encoded string.
     * @property CUSTOM {string} Messages are free-form strings. The application is responsible for encoding/decoding the information transmitted.
     */
    CastMessageBus.MessageType = {
        STRING: "STRING",
        JSON: "JSON",
        CUSTOM: "CUSTOM"
    };

    /**
     * @name CastMessageBus.EventType
     * @type {{MESSAGE: string}}
     * @property MESSAGE {string} Fired when there is a message.
     */
    CastMessageBus.EventType = {
        MESSAGE: "message"
    };

    /**
     * @name CastMessageBusEvent
     * @desc Event raised when a new message is received on the message bus for a specific namespace.
     * @param type event type
     * @param senderId The sender Id.
     * @param data {*} Application message.
     * @constructor
     * @extends goog.events.Event
     * @event
     */
    var CastMessageBusEvent = function (type, senderId, data) {
        goog.events.Event.call(this, type);
        this.senderId = senderId;
        this.data = data
    };
    goog.inherits(CastMessageBusEvent, goog.events.Event);


    /**
     * @name CastMessageBus.Event
     * @desc Event raised when a new message is received on the message bus for a specific namespace.
     * @type {CastMessageBusEvent}
     * @event
     */
    CastMessageBus.Event = CastMessageBusEvent;

    /**
     * @name CastMessageBusEvent#logger
     * @desc logger for CastMessageBus
     */
    CastMessageBus.prototype.logger = goog.debug.Logger.getLogger("cast.receiver.CastMessageBus");

    /**
     * @name CastMessageBusEvent#getDebugString
     * @desc get cast message bus debug message string for CastMessageBus
     * @method CastMessageBusEvent#getDebugString
     */
    CastMessageBus.prototype.getDebugString = function () {
        return "CastMessageBus[" + this.ns + "]"
    };

    /**
     * @name CastMessageBus#getNamespace
     * @desc The namespace of the messages processed by this CastMessageBus.
     * @method CastMessageBus#getNamespace
     */
    CastMessageBus.prototype.getNamespace = function () {
        return this.ns;
    };

    /**
     * @name CastMessageBus#getMessageType
     * @desc The type of messages processed by this CastMessageBus.
     * @method CastMessageBus#getMessageType
     */
    CastMessageBus.prototype.getMessageType = function () {
        return this.messageType;
    };

    /**
     * @name CastMessageBus#dispatchMessage
     * @desc dispatch message on CastMessageBus
     * @param message
     * @method CastMessageBus#dispatchMessage
     * @private
     */
    CastMessageBus.prototype.dispatchMessage = function (message) {
        this.logger.finer("Dispatching CastMessageBus message [" + this.ns + ", " + message.senderId + "]: " + message.data);

        var data = ("STRING" == this.messageType) ? message.data : this.deserializeMessage(message.data);

        this.dispatchEvent(new CastMessageBusEvent(message.senderId, message.senderId, data));

        var event = new CastMessageBusEvent("message", message.senderId, data);

        if (this.onMessage) {
            this.onMessage(event);
        }

        this.dispatchEvent(event)
    };

    /**
     * @name CastMessageBus#send
     * @desc Sends a message to a specific sender.
     * @param senderId
     * @param message
     * @method CastMessageBus#send
     */
    CastMessageBus.prototype.send = function (senderId, message) {
        if ("STRING" == this.messageType) {
            if (!goog.isString(message)) {
                throw Error("Wrong argument, CastMessageBus type is STRING");
            }
            this.ipcChannel.send(this.ns, senderId, message)
        } else {
            this.ipcChannel.send(this.ns, senderId, this.serializeMessage(message))
        }
    };

    /**
     * @name CastMessageBus#broadcast
     * @desc Sends a message to all the senders connected.
     * @param message
     * @method CastMessageBus#broadcast
     */
    CastMessageBus.prototype.broadcast = function (message) {
        this.send("*:*", message)
    };

    /**
     * @name CastMessageBus#getCastChannel
     * @desc Provides a {cast.receiver.CastChannel} for a specific senderId.
     * @param senderId
     * @returns {*}
     * @method CastMessageBus#getCastChannel
     */
    CastMessageBus.prototype.getCastChannel = function (senderId) {
        if (senderId in this.channels) {
            if (!this.channels[senderId]) {
                this.channels[senderId] = new CastChannel(this, senderId);
            }
            return this.channels[senderId];
        }
        throw Error("Requested a socket for a disconnected sender: " + senderId);
    };

    /**
     * @name CastMessageBus#serializeMessage
     * @desc Serializes a deserialized message.
     * @param message
     * @returns {*}
     * @method CastMessageBus#serializeMessage
     */
    CastMessageBus.prototype.serializeMessage = function (message) {
        if ("JSON" != this.messageType) {
            throw Error("Unexpected message type for JSON serialization");
        }
        return JSON.stringify(message)
    };

    /**
     * @name CastMessageBus#deserializeMessage
     * @desc Deserializes a serialized message.
     * @param message
     * @returns {*}
     * @method CastMessageBus#deserializeMessage
     */
    CastMessageBus.prototype.deserializeMessage = function (message) {
        if ("JSON" != this.messageType) {
            throw Error("Unexpected message type for JSON serialization");
        }
        return JSON.parse(message)
    };

    /**
     * @name CastMessageBus#disposeInternal
     * @desc dispose internal
     * @method CastMessageBus#disposeInternal
     * @private
     */
    CastMessageBus.prototype.disposeInternal = function () {
        CastMessageBus.superClass_.disposeInternal.call(this);
        if (this.channels) {
            for (var i in this.channels) {
                if (this.channels[i]) {
                    this.channels[i].close();
                }
            }
            this.channels = {}
        }
        this.logger.finer("Disposed " + this.getDebugString());
    };

    var inactivity_config = {
        statusText: void 0,
        maxInactivity: 10 //最大空闲时间
    };

    /**
     * @name CastReceiverManager
     * @class Initializes the system manager so we can communicate with the platform.
     * @desc This class is used to send/receive system messages/events. It must only be instantiated just once (singleton). Extends goog.events.EventTarget. Implements EventTarget.
     * @constructor
     * @extends goog.events.EventTarget
     */
    var CastReceiverManager = function () {
        goog.events.EventTarget.call(this);

        if (this.console = new goog.debug.Console) {
            this.console.setCapturing(true);

            // var console = this.console;
            // if (!console.isCapturing_) {

                // goog.debug.LogManager.initialize();
                // var castReceiverManagerLogger = logger,
                //     c = console.publishHandler_;
                // castReceiverManagerLogger.rootHandlers_ || (castReceiverManagerLogger.rootHandlers_ = []);
                // castReceiverManagerLogger.rootHandlers_.push(c);
            // }
        }

        this.inactivity_config = goog.object.clone(inactivity_config);
        this.ipcChannel = new IpcChannel;
        this.senders = {};
        this.systemSender = new CastMessageBus("urn:x-cast:com.google.cast.system", this.ipcChannel, goog.object.getKeys(this.senders), "JSON");

        this.addOnDisposeCallback(goog.partial(goog.dispose, this.systemSender));

        this.started = false;
        this.systemReady = false;
        this.messageBusList = {};

        this.onVisibilityChanged = null;
        this.onSystemVolumeChanged = null;
        this.onSenderDisconnected = null;
        this.onSenderConnected = null;
        this.onReady = null;

        goog.events.listen(this.systemSender, "SystemSender", this.listenerCallback, false, this)
    };
    goog.inherits(CastReceiverManager, goog.events.EventTarget);

    /**
     * @name CastReceiverManager#getInstance
     * @desc get receiver manager instance.
     * @returns {CastReceiverManager|*}
     * @method CastReceiverManager#getInstance
     */
    CastReceiverManager.getInstance = function () {
        if (!CastReceiverManager.instance) {
            CastReceiverManager.instance = new CastReceiverManager;
        }
        return CastReceiverManager.instance;
    };

    /**
     * @name CastReceiverManager.EventType
     * @desc event type for CastReceiverManager
     * @type {{OPENED: string, CLOSED: string, READY: string, SHUTDOWN: string, SENDER_CONNECTED: string, SENDER_DISCONNECTED: string, ERROR: string, SYSTEM_VOLUME_CHANGED: string, VISIBILITY_CHANGED: string}}
     * @property OPENED {string} Fired when the application is opened.
     * @property CLOSED {string} ired when the application is closed.
     * @property READY {string} Fired when the system is ready.
     * @property SHUTDOWN {string} Fired when the application is terminated.
     * @property SENDER_CONNECTED {string} Fired when a new sender has connected.
     * @property SENDER_DISCONNECTED {string} Fired when a sender has disconnected.
     * @property ERROR {string} Fired when there is a system error.
     * @property SYSTEM_VOLUME_CHANGED {string} Fired when the system volume has changed.
     * @property VISIBILITY_CHANGED {string} Fired when the visibility of the application has changed (for example after a HDMI Input change or when the TV is turned off/on and the cast device is externally powered). Note that this API has the same effect as the webkitvisibilitychange event raised by your document, we provided it as CastReceiverManager API for convenience and to avoid a dependency on a webkit-prefixed event.
     */
    CastReceiverManager.EventType = {
        OPENED: "opened",
        CLOSED: "closed",
        READY: "ready",
        SHUTDOWN: "shutdown",
        SENDER_CONNECTED: "senderconnected",
        SENDER_DISCONNECTED: "senderdisconnected",
        ERROR: "error",
        SYSTEM_VOLUME_CHANGED: "systemvolumechanged",
        VISIBILITY_CHANGED: "visibilitychanged"
    };

    /**
     * @name DataEvent
     * @desc Event dispatched by cast.receiver.CastReceiverManager which contains system information.
     * @param type event type
     * @param data Data associated with this event.
     * @constructor
     * @extends goog.events.Event
     * @event
     */
    var DataEvent = function (type, data) {
        goog.events.Event.call(this, type);
        this.data = data
    };
    goog.inherits(DataEvent, goog.events.Event);

    /**
     * @name CastReceiverManager.Event
     * @desc Event dispatched by cast.receiver.CastReceiverManager which contains system information.
     * @type {DataEvent}
     * @event
     */
    CastReceiverManager.Event = DataEvent;

    /**
     * @name CastReceiverManager.Config
     * @desc Application configuration parameters.
     * @constructor
     */
    CastReceiverManager.Config = function () {
        /** Maximum time in seconds before closing an idle sender connection.*/
        this.maxInactivity = null;
        /** Text that represents the application status. */
        this.statusText = null;
    };

    /**
     * @name CastReceiverManager#logger
     * @desc logger of CastReceiverManager
     */
    CastReceiverManager.prototype.logger = goog.debug.Logger.getLogger("cast.receiver.CastReceiverManager");

    /**
     * @name CastReceiverManager#getDebugString
     * @desc get debug string of CastReceiverManager
     * @returns {string}
     * @method CastReceiverManager#getDebugString
     */
    CastReceiverManager.prototype.getDebugString = function () {
        return "CastReceiverManager"
    };

    /**
     * @name CastReceiverManager#start
     * @desc Initializes the system manager. The application should call this method when it is ready to start receiving messages, typically after registering to listen for the events it is interested on.
     * @param config {CastReceiverManager.Config} config data
     * @method CastReceiverManager#start
     */
    CastReceiverManager.prototype.start = function (config) {
        if (config) {
            if (!config) {
                throw Error("Cannot validate undefined config.");
            }

            if (config.maxInactivity != 0 && config.maxInactivity < 5) {
                throw Error("config.maxInactivity must be greater than or equal to 5 seconds.");
            }

            goog.object.extend(this.inactivity_config, config || {})
        }
        this.started = true;
        this.ipcChannel.open();
    };

    /**
     * @name CastReceiverManager#stop
     * @desc Terminates the application. It can be called by the application to kill itself, it has to be the last method called.
     * @method CastReceiverManager#stop
     */
    CastReceiverManager.prototype.stop = function () {
        //this.G();
        window.close()
    };

    /**
     * @name CastReceiverManager#isSystemReady
     * @desc When the application calls start, the system will send the ready event to indicate that the application information is ready and the application can send messages as soon as there is one sender connected.
     * @returns {boolean|*} Whether or not the system is ready to process messages.
     * @method CastReceiverManager#isSystemReady
     */
    CastReceiverManager.prototype.isSystemReady = function () {
        return this.systemReady
    };

    /**
     * @name CastReceiverManager#getSenders
     * @desc Provides a list of the senders currently connected to the application. Must not be null.
     * @returns {*} The list of senderIds connected to the application. Must not be null.
     * @method CastReceiverManager#getSenders
     */
    CastReceiverManager.prototype.getSenders = function () {
        //getKeys
        return goog.object.getKeys(this.senders)
    };

    /**
     * @name CastReceiverManager#getSender
     * @desc Provides a copy of the sender object by senderId.
     * @param senderId {String} SenderId of the connected sender.
     * @returns {*} Sender object or null if not found.
     * @method CastReceiverManager#getSender
     */
    CastReceiverManager.prototype.getSender = function (senderId) {
        if (this.senders[senderId] != null) {
            return goog.object.clone(this.senders[senderId]);
        }
        return null;
    };

    /**
     * @name CastReceiverManager#getApplicationData
     * @desc Provides application information once the system is ready, otherwise it will be null.
     * @returns {{id: *, name: *, sessionId: *, namespaces: *, launchingSenderId: *}|*} The application information.
     * @method CastReceiverManager#getApplicationData
     */
    CastReceiverManager.prototype.getApplicationData = function () {
        return this.appData
    };

    /**
     * @name CastReceiverManager#setApplicationState
     * @desc Sets the application state. The application should call it when its state changes.
     * @param statusText {string} The status text.
     * @method CastReceiverManager#setApplicationState
     */
    CastReceiverManager.prototype.setApplicationState = function (statusText) {
        if (this.systemReady) {
            var message = {
                type: "setappstate"
            };

            if (statusText != null) {
                message.statusText = statusText;
            }

            this.systemSender.send("SystemSender", message);

        } else {
            this.inactivity_config.statusText = statusText;
        }
    };

    /**
     * @name CastReceiverManager#getCastMessageBus
     * @desc Provides a channel for a specific namespace (for any sender).Must not be null.
     * @param ns {string} The namespace. Note that a valid namespace has to be prefixed with the string 'urn:x-cast:'.
     * @param messageType {CastMessageBus.MessageType} The type of messages supported by the namespace. Optional.
     * @returns {*} The namespace channel. Must not be null.
     * @method CastReceiverManager#getCastMessageBus
     */
    CastReceiverManager.prototype.getCastMessageBus = function (ns, messageType) {
        if (ns == "urn:x-cast:com.google.cast.system") {
            throw Error("Protected namespace");
        }

        if (0 != ns.lastIndexOf("urn:x-cast:", 0)) {
            throw Error("Invalid namespace prefix");
        }

        if (!this.messageBusList[ns]) {
            if (this.started) {
                throw Error("New namespaces can not be requested after start has been called");
            }
            this.messageBusList[ns] = new CastMessageBus(ns, this.ipcChannel, goog.object.getKeys(this.senders), messageType);

            this.addOnDisposeCallback(goog.partial(goog.dispose, this.messageBusList[ns]))
        }

        if (messageType && this.messageBusList[ns].getMessageType() != messageType) {
            throw Error("Invalid messageType for the namespace");
        }

        return this.messageBusList[ns]
    };

    /**
     * @name CastReceiverManager#listenerCallback
     * @desc listener callback, used internal
     * @param message
     * @private
     * @method CastReceiverManager#listenerCallback
     */
    CastReceiverManager.prototype.listenerCallback = function (message) {
        var dataEvent,
            b = message.data; //CastMessageBus

        this.logger.finer("CastReceiverManager message received: " + message.data);
        switch (b.type) {
            case CastReceiverManager.EventType.OPENED:
                this.logger.info("Underlying message bus is open");

                message = { type: "ready" };

                if (this.inactivity_config.statusText) {
                    message.statusText = this.inactivity_config.statusText;
                }

                message.activeNamespaces = goog.object.getKeys(this.messageBusList);
                message.version = "2.0.0";
                message.messagesVersion = "1.0";
                this.systemSender.send("SystemSender", message);

                this.inactivity_config.maxInactivity && this.systemSender.send("SystemSender", {
                    type: "startheartbeat",
                    maxInactivity: this.inactivity_config.maxInactivity
                });
                break;

            case CastReceiverManager.EventType.CLOSED:
                this.systemReady = false;
                this.dispatchEvent("shutdown");
                break;

            case CastReceiverManager.EventType.ERROR:
                this.dispatchEvent("error");
                break;

            case CastReceiverManager.EventType.READY:
                this.appData = {
                    id: b.applicationId,
                    name: b.applicationName,
                    sessionId: b.sessionId,
                    namespaces: goog.object.getKeys(this.messageBusList),
                    launchingSenderId: b.launchingSenderId
                };
                this.systemReady = true;
                this.logger.info("Dispatching CastReceiverManager system ready event [" + this.appData + "]");
                var event = new DataEvent("ready", this.appData);
                if (this.onReady) {
                    this.onReady(event);
                }
                this.dispatchEvent(event);
                break;

            case CastReceiverManager.EventType.SENDER_CONNECTED:
                var d = {
                    id: b.senderId,
                    userAgent: b.userAgent
                };
                this.logger.info("Dispatching CastReceiverManager sender connected event [" + d.id + "]");
                if(d.id in this.senders){
                    this.logger.severe("Unexpected connected message for already connected sender: " + d.id);
                }
                
                this.senders[d.id] = d;
                dataEvent = new DataEvent("senderconnected", d.id);
                for (c in this.messageBusList) {
                    var messageBus = this.messageBusList[c];
                    if(d.id in messageBus.channels){
                        messageBus.logger.severe("Unexpected sender already registered [" + messageBus.ns + ", " + d.id + "]");
                    }else{
                        messageBus.logger.info("Registering sender [" + messageBus.ns + ", " + d.id + "]");
                        messageBus.channels[d.id] = null;
                    }
                }
                if (this.onSenderConnected){
                    this.onSenderConnected(dataEvent);
                } 
                this.dispatchEvent(dataEvent);
                break;

            case CastReceiverManager.EventType.SENDER_DISCONNECTED:
                var c = b.senderId;
                this.logger.info("Dispatching sender disconnected event [" + c + "]");
                if (c in this.senders) {
                    delete this.senders[c];
                    dataEvent = new DataEvent("senderdisconnected", c);
                    for (d in this.messageBusList) {
                        b = this.messageBusList[d];
                        var e = c;
                        if(e in b.channels){
                            b.logger.info("Unregistering sender [" + b.ns + ", " + e + "]"), 
                            b.channels[e] && b.channels[e].close(), 
                            delete b.channels[e];
                        }
                    }

                    if (this.onSenderDisconnected) {
                        this.onSenderDisconnected(dataEvent);
                    }

                    this.dispatchEvent(dataEvent)
                } else this.logger.severe("Unknown sender disconnected: " + c);
                break;

            case CastReceiverManager.EventType.SYSTEM_VOLUME_CHANGED:
                var c = {
                    level: b.level,
                    muted: b.muted
                };
                this.logger.info("Dispatching system volume changed event [" + c.level + ", " + c.muted + "]");
                dataEvent = new DataEvent("systemvolumechanged", c);
                if (this.onSystemVolumeChanged) this.onSystemVolumeChanged(dataEvent);
                this.dispatchEvent(dataEvent);
                break;

            case CastReceiverManager.EventType.VISIBILITY_CHANGED:
                var c = b.visible;
                this.logger.info("Dispatching visibility changed event " + c);
                dataEvent = new DataEvent("visibilitychanged", c);
                if (this.onVisibilityChanged){
                    this.onVisibilityChanged(c);
                }
                this.dispatchEvent(c);
                break;

            default:
                throw Error("Unexpected message type: " + b.type);
        }
    };

    /**
     * @name CastReceiverManager#disposeInternal
     * @desc dispose internal
     * @private
     * @method CastReceiverManager#disposeInternal
     */
    CastReceiverManager.prototype.disposeInternal = function () {
        CastReceiverManager.superClass_.disposeInternal.call(this);
        delete CastReceiverManager.instance;
        this.logger.fine("Disposed " + this.getDebugString());
    };

    /**
     * @name MediaErrorType
     * @property INVALID_PLAYER_STATE
     * @property LOAD_FAILED
     * @property LOAD_CANCELLED
     * @property INVALID_REQUEST
     * @type {{INVALID_PLAYER_STATE: string, LOAD_FAILED: string, LOAD_CANCELLED: string, INVALID_REQUEST: string}}
     */
    var MediaErrorType = {
        INVALID_PLAYER_STATE: "INVALID_PLAYER_STATE",
        LOAD_FAILED: "LOAD_FAILED",
        LOAD_CANCELLED: "LOAD_CANCELLED",
        INVALID_REQUEST: "INVALID_REQUEST"
    };

    /**
     * @name MediaInformation
     * @desc Represents the media information.
     * @constructor
     */
    var MediaInformation = function () {
        this.contentId = "";
        this.streamType = "NONE";
        this.contentType = "";
        this.customData = null;
        this.duration = 0;
        this.metadata = null;
    };

    /**
     * @name Volume
     * @desc Represents the volume of a media session stream.
     * @constructor
     */
    var Volume = function () {
        this.muted = this.level = void 0
    };

    /**
     * @name MediaStatus
     * @desc Represents the status of a media session.
     * @constructor
     */
    var MediaStatus = function () {
        this.mediaSessionId = 0;
        this.media = void 0;
        this.playbackRate = 1;
        this.playerState = "IDLE";
        this.idleReason = null;
        this.supportedMediaCommands = 0;
        this.currentTime = 0;
        this.volume = {
            level: 0,
            muted: false
        };
        this.customData = null;
    };

    /**
     * @name Command
     * @desc Commands supported by cast.receiver.MediaManager.
     * @property PAUSE {number} Pause Command.
     * @property SEEK {number} Seek Command.
     * @property STREAM_VOLUME {number} Stream Volume Command.
     * @property STREAM_MUTE {number} Stream Volume Command.
     * @type {{PAUSE: number, SEEK: number, STREAM_VOLUME: number, STREAM_MUTE: number}}
     */
    var Command = {
        PAUSE: 1,
        SEEK: 2,
        STREAM_VOLUME: 4,
        STREAM_MUTE: 8
    };

    /**
     * @name MediaManager
     * @class Creates a media manager instance.
     * @desc  This class is used to send/receive media messages/events. Extends goog.events.EventTarget. Implements EventTarget.
     * @param mediaElement
     * @param opt_supportedCommands
     * @constructor
     * @extends goog.events.EventTarget
     */
    var MediaManager = function (mediaElement, opt_supportedCommands) {
        goog.events.EventTarget.call(this);
        this.castMessageBus = CastReceiverManager.getInstance().getCastMessageBus("urn:x-cast:com.google.cast.media", "JSON");
        this.mediaSessionId = 0; //this.fa
        this.playbackRate = 1; // this.Xa
        this.supportedMediaCommands = opt_supportedCommands || 15; // this.Ya
        
        this.mediaStatusSenderTime = null; // this.Aa
        this.mediaStatusSenderCurrentTime = null; // this.za
        this.currentTime = null; // this.C
        this.loadTime = 0; //this.ea

        this.oMediaInformation = null; // this.W
        this.mediaInformation = null; //MediaInformation
        this.mediaElement = null; //MediaElement<video/audio> this.b
        this.media = null; //this.c

        this.isPlayerBuffering = false; // this.l
        this.idleReason = null; // this.L
        this.loadInfo = null; // this.f

        this.setMediaElement(mediaElement);
        this.castMessageBus.onMessage = this.onMessage.bind(this);
        goog.Timer.callOnce(goog.bind(this.bufferState, this), 1000);
    };
    goog.inherits(MediaManager, goog.events.EventTarget);

    /**
     * @name MediaManager.EventType
     * @desc System events dispatched by cast.receiver.MediaManager.
     * @property LOAD {string} Fired when there is a load message.
     * @property STOP {string} Fired when there is a stop message.
     * @property PAUSE {string} Fired when there is a pause message.
     * @property PLAY {string} Fired when there is a play message.
     * @property SEEK {string} Fired when there is a seek message.
     * @property SET_VOLUME {string} Fired when there is a set volume message.
     * @property GET_STATUS {string} Fired when there is a get status message.
     * @type {{LOAD: string, STOP: string, PAUSE: string, PLAY: string, SEEK: string, SET_VOLUME: string, GET_STATUS: string}}
     */
    MediaManager.EventType = {
        LOAD: "load",
        STOP: "stop",
        PAUSE: "pause",
        PLAY: "play",
        SEEK: "seek",
        SET_VOLUME: "setvolume",
        GET_STATUS: "getstatus"
    };

    /**
     * @name MediaManagerEvent
     * @desc media manager event
     * @param a
     * @param b
     * @param c
     * @constructor
     * @extends goog.events.Event
     * @event
     */
    var MediaManagerEvent = function (a, b, c) {
        goog.events.Event.call(this, a);
        this.data = b;
        this.senderId = c
    };
    goog.inherits(MediaManagerEvent, goog.events.Event);

    goog.exportSymbol("cast.receiver.MediaManager", MediaManager);

    /**
     * @name MediaManager.Event
     * @desc Event dispatched by cast.receiver.MediaManager which contains system information
     * @type {MediaManagerEvent}
     * @event
     */
    MediaManager.Event = MediaManagerEvent;

    /**
     * @name RequestData
     * @desc request data
     * @constructor
     */
    var RequestData = function () {
        this.requestId = 0;
        this.mediaSessionId = void 0;
        this.customData = null;
    };

    /**
     * @name MediaManager.RequestData
     * @desc Request data associated with this event.
     * @type {RequestData}
     */
    MediaManager.RequestData = RequestData;

    /**
     * @name LoadRequestData
     * @desc Media event LOAD request data.
     * @constructor
     * @extends RequestData
     */
    var LoadRequestData = function () {
        this.media = new MediaInformation;
        this.autoplay = false;
        this.currentTime = 0;
    };

    goog.inherits(LoadRequestData, RequestData);

    /**
     * @name MediaManager.LoadRequestData
     * @desc Media event LOAD request data.
     * @type {LoadRequestData}
     */
    MediaManager.LoadRequestData = LoadRequestData;

    /**
     * @name VolumeRequestData
     * @desc Media event SET_VOLUME request data
     * @constructor
     * @extends RequestData
     */
    var VolumeRequestData = function () {
        this.volume = new Volume
    };

    goog.inherits(VolumeRequestData, RequestData);

    /**
     * @name MediaManager.VolumeRequestData
     * @desc Media event SET_VOLUME request data.
     * @type {VolumeRequestData}
     */
    MediaManager.VolumeRequestData = VolumeRequestData;

    /**
     * @name MediaManager.SeekRequestData
     * @desc Media event SEEK request data ///????????????????????????????!!!need check.
     * @constructor
     */
    MediaManager.SeekRequestData = function () {
        this.resumeState = void 0;
        this.currentTime = 0
    };

    /**
     * @name MediaManager.LoadInfo
     * @desc Load Request Information////????
     * @param message
     * @param senderId
     * @constructor
     */
    MediaManager.LoadInfo = function (message, senderId) {
        this.message = message;
        this.senderId = senderId;
    };

    /**
     * @name MediaManager#logger
     * @desc logger of MediaManager
     */
    MediaManager.prototype.logger = goog.debug.Logger.getLogger("cast.receiver.MediaManager");

    /**
     * @name MediaManager#getDebugString
     * @desc get debug string of MediaManager
     * @returns {string}
     * @method MediaManager#getDebugString
     */
    MediaManager.prototype.getDebugString = function () {
        return "MediaManager"
    };

    /**
     * @name MediaManager#getMediaInformation
     * @desc Provides information about the media currently loaded.
     * @returns {null|*} The media information.
     * @method MediaManager#getMediaInformation
     */
    MediaManager.prototype.getMediaInformation = function () {
        return this.mediaInformation
    };

    /**
     * @name MediaManager#setMediaInformation
     * @desc Sets information about the media currently loaded. This information will be sent to the senders when they request media status.
     * @param mediaInformation {MediaInformation} The new media information. Use resetMediaElement to reset its value. Must not be null.
     * @param opt_broadcast {boolean} Whether the senders should be notified about the change (if not provided, the senders will be notified). Optional.
     * @param opt_broadcastStatusCustomData {*} If the senders should be notified this parameter allows to set the application-specific custom data in the status message. Optional.
     * @method MediaManager#setMediaInformation
     */
    MediaManager.prototype.setMediaInformation = function (mediaInformation, opt_broadcast, opt_broadcastStatusCustomData) {
        opt_broadcast = void 0 == opt_broadcast || opt_broadcast;
        if (opt_broadcastStatusCustomData && !opt_broadcast){
            throw Error("No broadcast call but status customData has been provided");
        } 
        this.mediaInformation = mediaInformation;
        if(opt_broadcast){
            this.broadcastStatus(!0, null, opt_broadcastStatusCustomData);
        }
    };

    /**
     * @name MediaManager#onMessage
     * @desc received message
     * @param a
     * @private
     * @method MediaManager#onMessage
     */
    MediaManager.prototype.onMessage = function (a) {
        var b = a.data;
        a = a.senderId;

        var c = b.type;
        var d = b.requestId;

        if ("number" == typeof d && d == Math.floor(d))
            if (void 0 != b.mediaSessionId && b.mediaSessionId != this.mediaSessionId || "LOAD" != c && "GET_STATUS" != c && ("IDLE" == mediaState(this) || void 0 == b.mediaSessionId)) {
                this.logger.severe("Invalid media session ID: " + b.mediaSessionId);
                this.sendError(a, d, "INVALID_REQUEST", "INVALID_MEDIA_SESSION_ID");
            } else {
                this.logger.finer("MediaManager message received [" + a + "] " + JSON.stringify(b));
                delete b.type;
                var e = null;
                switch (c) {
                    case "LOAD":
                        this.logger.info("Dispatching MediaManager load event");
                        if (b.media) {
                            if (this.loadInfo) {
                                this.sendLoadError("LOAD_CANCELLED")
                            } else if (this.mediaInformation) {
                                this.resetMediaElement("INTERRUPTED");
                            }
                            this.loadInfo = {
                                senderId: a,
                                message: b
                            };
                            this.loadTime = b.currentTime || 0;
                            this.mediaInformation = b.media;
                            this.mediaSessionId++;
                            b = new MediaManagerEvent("load", b, a);
                            if (this.onLoad) {
                                this.onLoad(b);
                            }
                            this.dispatchEvent(b);
                            e = null
                        } else {
                            this.logger.severe("media is mandatory");
                            e = {
                                type: "INVALID_REQUEST",
                                reason: "INVALID_PARAMS"
                            };
                        }
                        break;

                    case "GET_STATUS":
                        this.logger.info("Dispatching MediaManager getStatus event");
                        b = new MediaManagerEvent("getstatus", b, a);
                        if (this.onGetStatus) {
                            this.onGetStatus(b);
                        }
                        this.dispatchEvent(b);
                        e = null;
                        break;

                    case "PLAY":
                        this.logger.info("Dispatching MediaManager play event");
                        b = new MediaManagerEvent("play", b, a);
                        if (this.onPlay) {
                            this.onPlay(b);
                        }
                        this.dispatchEvent(b);
                        e = null;
                        break;

                    case "SEEK":
                        if (0 == b.currentTime) {
                            this.logger.severe("currentTime is mandatory");
                            e = {
                                type: "INVALID_REQUEST",
                                reason: "INVALID_PARAMS"
                            };
                        } else {
                            this.logger.info("Dispatching MediaManager seek event");
                            b = new MediaManagerEvent("seek", b, a);
                            if (this.onSeek) {
                                this.onSeek(b);
                            }
                            this.dispatchEvent(b);
                            e = null
                        }
                        break;

                    case "STOP":
                        this.logger.info("Dispatching MediaManager stop event");
                        b = new MediaManagerEvent("stop", b, a);
                        if (this.onStop) {
                            this.onStop(b);
                        }
                        this.dispatchEvent(b);
                        e = null;
                        break;

                    case "PAUSE":
                        this.logger.info("Dispatching MediaManager pause event");
                        b = new MediaManagerEvent("pause", b, a);
                        if (this.onPause) {
                            this.onPause(b);
                        }
                        this.dispatchEvent(b);
                        e = null;
                        break;

                    case "SET_VOLUME":
                        if (!b.volume || void 0 == b.volume.level && void 0 == b.volume.muted) {
                            this.logger.severe("volume is invalid");
                            e = {
                                type: "INVALID_REQUEST",
                                reason: "INVALID_PARAMS"
                            };
                        } else if (b.volume.level < 0 || b.volume.level > 1) {
                            this.logger.severe("volume level is invalid");
                            e = {
                                type: "INVALID_REQUEST",
                                reason: "INVALID_PARAMS"
                            };
                        } else {
                            this.logger.info("Dispatching MediaManager setvolume event");
                            b = new MediaManagerEvent("setvolume", b, a);
                            if (this.onSetVolume) {
                                this.onSetVolume(b);
                            }
                            this.dispatchEvent(b);
                            e = null
                        }
                        break;

                    default:
                        this.logger.severe("Unexpected message type: " + c);
                        e = {
                            type: MediaErrorType.INVALID_COMMAND
                        }
                }
                if (e) {
                    this.logger.severe("Sending error: " + e.type + " " + e.reason);
                    this.sendError(a, d, e.type, e.reason);
                }
            } else {
                this.logger.severe("Ignoring request, requestId is not an integer: " + d);
            }
    };

    /**
     * @name mediaState
     * @desc media state
     * @param mediaManager
     * @returns {*}
     */
    var mediaState = function (mediaManager) {
        if (!mediaManager.mediaInformation){
            return "IDLE";   
        }
        if (mediaManager.media) {
            var b = mediaManager.media.getState();
            if("PLAYING" == b && mediaManager.isPlayerBuffering){
                return "BUFFERING";
            }else{
                return b;
            }
        }
        //当为暂停状态
        if(mediaManager.mediaElement.paused){
            //当视频/音频没有播放完毕
            if(mediaManager.mediaElement.duration && (mediaManager.mediaElement.currentTime || 0 == mediaManager.mediaElement.currentTime) && mediaManager.mediaElement.duration != mediaManager.mediaElement.currentTime){
                //当为“加载完成立即播放状态”并且当前时间等于缓冲完成时间 todo
                if(mediaManager.mediaElement.currentTime == mediaManager.loadTime && mediaManager.mediaElement.autoplay){
                    return "BUFFERING";
                }else{
                    return "PAUSED";
                }
                    
            }else{ 
                return "IDLE";
            }
        }else {
             if(mediaManager.isPlayerBuffering){
                return "BUFFERING";
             }else{
                return "PLAYING";
             }
        }
    };

    /**
     * @name getMediaStatus
     * @desc get media status
     * @param mediaManager
     * @param b
     * @param c
     * @returns {{type: string}}
     */
    var getMediaStatus = function (mediaManager, b, c) {
        var d = {
            type: "MEDIA_STATUS"
        };
        if (!mediaManager.mediaInformation && !mediaManager.oMediaInformation){
            d.status = [];
            return d;  
        } 
        var e = mediaManager.media ? mediaManager.media.getVolume() : {
            level: mediaManager.mediaElement.volume,
            muted: mediaManager.mediaElement.muted
        }, e = {
            mediaSessionId: mediaManager.mediaSessionId,
            playbackRate: mediaManager.playbackRate,
            playerState: mediaState(mediaManager),
            currentTime: mediaManager.media ? mediaManager.media.getCurrentTimeSec() : mediaManager.mediaElement.currentTime,
            supportedMediaCommands: mediaManager.supportedMediaCommands,
            volume: e
        };

        if(b){
            e.media = mediaManager.mediaInformation || mediaManager.oMediaInformation || void 0;
        }
        if(!mediaManager.mediaInformation){
            mediaManager.oMediaInformation = null;
        }
        if("IDLE" == e.playerState){
            if(mediaManager.idleReason){
                e.idleReason = mediaManager.idleReason;
            }
        } else{
            mediaManager.idleReason = null;  
        } 
        if(c !=undefined){
            e.customData = c;
        }

        if(mediaManager.customizedStatusCallback){
            var mediaStatus = mediaManager.customizedStatusCallback(e);
            if(null == mediaStatus){
                d = null;
            }else{
                d.status = [mediaStatus];
            }
            mediaStatus = null;
        }else{ 
            d.status = [e];
        }
        return d;
    };

    /**
     * @name setMediaStatusSenderTime
     * @desc set media status sender time
     * @param mediaManager
     */
    var setMediaStatusSenderTime = function (mediaManager) {
        if(mediaManager.mediaElement){
            mediaManager.currentTime = mediaManager.mediaElement.currentTime;
            mediaManager.mediaStatusSenderCurrentTime = mediaManager.mediaElement.currentTime;
            mediaManager.mediaStatusSenderTime = Date.now();
        }
    };

    /**
     * @name MediaManager#bufferState
     * @desc buff state
     * @method MediaManager#bufferState
     */
    MediaManager.prototype.bufferState = function () {
        goog.Timer.callOnce(goog.bind(this.bufferState, this), 1000);
        //非暂停并且非空闲
        if ("IDLE" != mediaState(this) && "PAUSED" != mediaState(this)) {
            var a = this.currentTime;

            this.currentTime = this.media ? this.media.getCurrentTimeSec() : this.mediaElement.currentTime;

            var b = this.isPlayerBuffering;
            this.isPlayerBuffering = 100 > 1000 * (this.currentTime - a);
            
            if(b !=this.isPlayerBuffering) {
                this.logger.finer("Buffering state changed, isPlayerBuffering: " + this.isPlayerBuffering + " old time: " + a + " current time: " + this.currentTime);
                this.broadcastStatus(false);
            }else{
                if(!this.isPlayerBuffering){
                    if(a = 1000 * (this.currentTime - this.mediaStatusSenderCurrentTime) - (Date.now() - this.mediaStatusSenderTime), 1000 < a || -1000 > a){
                        this.logger.finer("Time drifted: " + a);
                        this.broadcastStatus(false);
                    }
                }
            }
        }
    };

    /**
     * @name MediaManager#broadcastStatus
     * @desc sends a media status message to all senders (broadcast). Applications can use it when they have a custom state change. It will call cast.receiver.MediaManager.prototype.customizedStatusCallback so applications can customize the status message.
     * @param a
     * @param b
     * @param c
     * @method MediaManager#broadcastStatus
     */
    MediaManager.prototype.broadcastStatus = function (a, b, c) {
        if(this.mediaElement || this.media){
            this.logger.finer("Sending broadcast status message");
            a = getMediaStatus(this, a, c);
            if(null != a){
                a.requestId = b || 0;
                this.castMessageBus.broadcast(a);
                setMediaStatusSenderTime(this);
            }
            
        }else{
            this.logger.severe("Not sending broadcast status message, state is invalid")
        }
    };

    /**
     * @name MediaManager#setIdleReason
     * @desc Sets the IDLE reason. This allows applications that want to force the IDLE state to indicate the reason that made the player going to IDLE state (a custom error, for example). The idle reason will be sent in the next status message. NOTE: Most applications do not need to set this value, it is only needed if they want to make the player go to IDLE in special circumstances and the default idleReason does not reflect their intended behavior.
     * @param idleReason The reason to be in the IDLE state.
     * @method MediaManager#setIdleReason
     */
    MediaManager.prototype.setIdleReason = function (idleReason) {
        this.logger.finer("Setting IDLE reason: " + idleReason);
        this.idleReason = idleReason
    };

    /**
     * @name MediaManager#sendError
     * @desc Sends an error to a specific sender.
     * @param senderId
     * @param requestId The sender ID.
     * @param type
     * @param opt_reason
     * @param opt_customData
     * @method MediaManager#sendError
     */
    MediaManager.prototype.sendError = function (senderId, requestId, type, opt_reason, opt_customData) {
        this.logger.info("Sending error message to " + senderId);
        var f = {};
        f.requestId = requestId;
        f.type = type;
        opt_reason && (f.reason = opt_reason);
        opt_customData && (f.customData = opt_customData);
        this.castMessageBus.send(senderId, f)
    };

    /**
     * @name MediaManager#sendStatus
     * @desc Sends a media status message to a specific sender.
     * @param senderId
     * @param requestId
     * @param includeMedia
     * @param opt_customData
     * @method MediaManager#sendStatus
     */
    MediaManager.prototype.sendStatus = function (senderId, requestId, includeMedia, opt_customData) {
        if(this.mediaElement || this.media){
            this.logger.finer("Sending status message to " + senderId);
            includeMedia = getMediaStatus(this, includeMedia, opt_customData);
            if(null != includeMedia){
                includeMedia.requestId = requestId;
                this.castMessageBus.send(senderId, includeMedia);
                setMediaStatusSenderTime(this);
            }
        }else{
            this.logger.severe("State is invalid"), 
            this.sendError(senderId, requestId, "INVALID_PLAYER_STATE", null, opt_customData);
        }
    };

    /**
     * @name MediaManager#customizedStatusCallback
     * @desc The application developer can override this method to customize the media status that will be send to the senders (this method will be called before the media status is sent). By providing this method application developers can, for example, add custom data to the media status. The current media status will be provided as a parameter and the method should return the application-modified current status. The default behavior is to return the incoming media status. If the method returns null the media status message will not be sent (developers should be aware that if the media status is a response to a sender status request the sender will expect a response so this method should only return null it if the developer is also overriding onGetStatus).May be null.
     * @param mediaStatus
     * @returns {*}
     * @method MediaManager#customizedStatusCallback
     */
    MediaManager.prototype.customizedStatusCallback = function (mediaStatus) {
        return mediaStatus;
    };

    /**
     * @name MediaManager#onLoad
     * @desc If provided, it processes the load event. The default behavior is to set the src and autoplay properties of the media element and call its load method. If provided, the currentTime property will be modified when the 'loadedmetadata' event is fired (in onMetadataLoaded) as it can only be set when the media element duration property has been set. If this method is overriden, the application developer may need to handle sendLoadError, sendLoadComplete and onMetadataLoaded. Please read the documentation of those APIs.May be null.
     * @param event
     * @method MediaManager#onLoad
     */
    MediaManager.prototype.onLoad = function (event) {
        var b = event.data;
        if(this.media){
            if(b.media && b.media.contentId){
                this.media.load(b.media.contentId, b.autoplay, b.currentTime);
            }
        }else{
            this.mediaElement.autoplay = false;
            if(b.media && event.data.media.contentId){
                this.mediaElement.src = b.media.contentId;
            }
            this.mediaElement.autoplay = void 0 != b.autoplay ? b.autoplay : true;
            this.mediaElement.load()
        }
    };

    /**
     * @name MediaManager#setMediaElement
     * @desc Associates a new media element or Player to the media manager.
     * @param mediaElement {*} The DOM media element (video/audio) or a player that implements the cast.receiver.media.Player interface. Must not be null.
     * @method MediaManager#setMediaElement
     */
    MediaManager.prototype.setMediaElement = function (mediaElement) {
        if(mediaElement.getState){
            if(this.mediaElement){
                unRegisterMediaElement(this); 
                this.mediaElement = null;
            }
            if(this.media != mediaElement){
                unRegisterMediaElement(this);
                this.media = mediaElement;
                registerMediaElement(this);
            }
        }else{
            if(this.media){
                unRegisterMediaElement(this);
                this.media = null;
            }
            if(this.mediaElement != mediaElement){
                unRegisterMediaElement(this);
                this.mediaElement = mediaElement;
                registerMediaElement(this);
            }
        }
    };

    /**
     * @name registerMediaElement
     * @desc register media element
     * @param mediaManager
     * @private
     */
    var registerMediaElement = function (mediaManager) {
        if(mediaManager.media){
            mediaManager.media.registerErrorCallback(mediaManager.loadMetadataError.bind(mediaManager)); 
            mediaManager.media.registerEndedCallback(mediaManager.ended.bind(mediaManager)); 
            mediaManager.media.registerLoadCallback(mediaManager.loadMetadata.bind(mediaManager));
        }else{
            goog.events.listen(mediaManager.mediaElement, "loadedmetadata", mediaManager.loadMetadata, false, mediaManager);
            goog.events.listen(mediaManager.mediaElement, "error", mediaManager.loadMetadataError, false, mediaManager); 
            goog.events.listen(mediaManager.mediaElement, "ended", mediaManager.ended, false, mediaManager);
        }
    };

    /**
     * @name unRegisterMediaElement
     * @desc unRegister media element
     * @param mediaManager
     * @private
     */
    var unRegisterMediaElement = function (mediaManager) {
        if(mediaManager.media){
            mediaManager.media.unregisterErrorCallback(); 
            mediaManager.media.unregisterEndedCallback();
            mediaManager.media.unregisterLoadCallback();
        }else{
            goog.events.unlisten(mediaManager.mediaElement, "loadedmetadata", mediaManager.loadMetadata, false, mediaManager); 
            goog.events.unlisten(mediaManager.mediaElement, "error", mediaManager.loadMetadataError, false, mediaManager); 
            goog.events.unlisten(mediaManager.mediaElement, "ended", mediaManager.ended, false, mediaManager);
        }
    };

    /**
     * @name MediaManager#loadMetadata
     * @desc load meta data
     * @private
     * @method MediaManager#loadMetadata
     */
    MediaManager.prototype.loadMetadata = function () {
        if (this.loadInfo){
            if(this.media){
                this.mediaInformation.duration = this.media.getDurationSec();
            }else{
                this.mediaInformation.duration = this.mediaElement.duration;
            }

            this.logger.info("Metadata loaded");
            this.isPlayerBuffering = true;
            if (this.mediaInformation && (this.mediaInformation.duration), this.onMetadataLoaded) {
                this.onMetadataLoaded(this.loadInfo);
            }else{
                this.loadInfo = null;
            } 
        }
    };

    /**
     * @name MediaManager#onMetadataLoaded
     * @desc Called when load has completed, it can be overridden to handle application specific action. The default behavior is to set the currentTime property of the media element (if it was provided in the LOAD request), then call sendLoadComplete.May be null.
     * @param a
     * @method MediaManager#onMetadataLoaded
     */
    MediaManager.prototype.onMetadataLoaded = function (a) {
        if (a.message.currentTime && this.mediaElement) {
            this.mediaElement.currentTime = a.message.currentTime;
        };
        this.sendLoadComplete();
    };

    /**
     * @name MediaManager#loadMetadataError
     * @desc Called when load has had an error, it can be overridden to handle application specific logic. The default behavior is to call resetMediaElement with idle reason ERROR and sendLoadError with error type LOAD_FAILED.May be null.
     * @param a
     * @method MediaManager#loadMetadataError
     */
    MediaManager.prototype.loadMetadataError = function (a) {
        if (this.loadInfo) {
            this.logger.severe("Load metadata error");
            if (this.onLoadMetadataError) {
                this.onLoadMetadataError(this.loadInfo);
            } else {
                this.loadInfo = null;
            }
        } else if (this.onError) {
            this.onError(a);
        }
    };

    /**
     * @name MediaManager#sendLoadError
     * @desc When the application overrides onLoad, it should use this method to trigger an error response to the sender. This is typically due to application-specific verification issues.
     * @param opt_errorType
     * @param opt_customData
     * @method MediaManager#sendLoadError
     */
    MediaManager.prototype.sendLoadError = function (opt_errorType, opt_customData) {
        if(this.loadInfo){
            this.sendError(this.loadInfo.senderId, this.loadInfo.message.requestId, opt_errorType || "LOAD_FAILED", null, opt_customData);
            this.loadInfo = null;
        }else{
            this.logger.severe("Not sending LOAD error as there is no on going LOAD request");
        }
    };

    /**
     * @name MediaManager#sendLoadComplete
     * @desc Sends the new status after a LOAD message has been completed successfully. Note: Applications do not normally need to call this API. When the application overrides onLoad, it may need to manually declare that the LOAD request was successful. The default implementaion will send the new status to the sender when the video/audio element raises the 'loadedmetadata' event. The default behavior may not be acceptable in a couple scenarios: 1) When the application does not want to declare LOAD successful until for example 'canPlay' is raised (instead of 'loadedmetadata'). 2) When the application is not actually loading the media element (for example if LOAD is used to load an image).
     * @param opt_customData
     * @method MediaManager#sendLoadComplete
     */
    MediaManager.prototype.sendLoadComplete = function (opt_customData) {
        if(this.loadInfo){
            this.broadcastStatus(!0, this.loadInfo.message.requestId, opt_customData);
            this.loadInfo = null;
        }else{
            this.logger.severe("Not sending status as there is no on going LOAD request");
        }
    };

    /**
     * @name MediaManager#onError
     * @desc Called when there is an error not triggered by a LOAD request. The default behavior is to call ResetMediaElement.May be null.
     * @method MediaManager#onError
     */
    MediaManager.prototype.onError = function () {
        this.resetMediaElement("ERROR");
    };

    /**
     * @name MediaManager#onLoadMetadataError
     * @desc Called when load has had an error, it can be overridden to handle application specific logic. The default behavior is to call resetMediaElement with idle reason ERROR and sendLoadError with error type LOAD_FAILED.May be null.
     * @method MediaManager#onLoadMetadataError
     */
    MediaManager.prototype.onLoadMetadataError = function () {
        this.resetMediaElement("ERROR", false);
        this.sendLoadError("LOAD_FAILED");
    };

    /**
     * @name MediaManager#ended
     * @desc Called when the media ends. The default behavior is to call ResetMediaElement with idle reason FINISHED.May be null.
     * @method MediaManager#ended
     */
    MediaManager.prototype.ended = function () {
        if (this.onEnded) {
            this.onEnded();
        }
    };

    /**
     * @name MediaManager#onEnded
     * @desc Called when the media ends. The default behavior is to call ResetMediaElement with idle reason FINISHED.May be null.
     * @method MediaManager#onEnded
     */
    MediaManager.prototype.onEnded = function () {
        this.resetMediaElement("FINISHED");
    };

    /**
     * @name MediaManager#onGetStatus
     * @desc Processes the get status event.May be null.
     * @param event
     * @method MediaManager#onGetStatus
     */
    MediaManager.prototype.onGetStatus = function (event) {
        this.logger.finer("onGetStatus");
        this.sendStatus(event.senderId, event.data.requestId, !0)
    };

    /**
     * @name MediaManager#onPlay
     * @desc Processes the play event. The default behavior is to call the media element's play method and broadcast the status providing the incoming requestId.
     * @param event
     * @method MediaManager#onPlay
     */
    MediaManager.prototype.onPlay = function (event) {
        this.logger.finer("onPlay");
        this.media ? this.media.play() : this.mediaElement.play();
        this.broadcastStatus(!1, event.data.requestId)
    };

    /**
     * @name MediaManager#onSeek
     * @desc Processes the seek event. The default behavior is to call the media element's play or pause methods (only if required based on the current state and the resume state value of the request) and broadcast the status providing the incoming requestId.
     * @param event
     * @method MediaManager#onSeek
     */
    MediaManager.prototype.onSeek = function (event) {
        var a = event.data;
        this.logger.finer("onSeek: " + JSON.stringify(a));
        if(this.media){
            this.media.seek(a.currentTime, a.resumeState);
            if("PAUSED" != this.media.getState()){
                this.isPlayerBuffering = true;
            }
        }else{
            if(this.mediaElement.currentTime = a.currentTime, "PLAYBACK_START" == a.resumeState && this.mediaElement.paused){
                this.mediaElement.play();
            }else{
                "PLAYBACK_PAUSE" != a.resumeState || this.mediaElement.paused || this.mediaElement.pause();
                this.mediaElement.paused || (this.isPlayerBuffering = !0);
            }
        }
        this.broadcastStatus(!1, a.requestId)
    };

    /**
     * @name MediaManager#onStop
     * @desc Processes the stop event. The default behavior is to call resetMediaElement, with idle reason CANCELLED, and broadcast the status providing the incoming requestId.
     * @param event
     * @method MediaManager#onStop
     */
    MediaManager.prototype.onStop = function (event) {
        this.resetMediaElement("CANCELLED", true, event.data.requestId)
    };

    /**
     * @name MediaManager#resetMediaElement
     * @desc Resets Media Element to IDLE state. After this call the mediaElement properties will change, paused will be true, currentTime will be zero and the src attribute will be empty. This only needs to be manually called if the developer wants to override the default behavior of onError, onStop or onEnded, for example.
     * @param opt_idleReason
     * @param opt_broadcast
     * @param opt_requestId
     * @param opt_broadcastStatusCustomData
     * @method MediaManager#resetMediaElement
     */
    MediaManager.prototype.resetMediaElement = function (opt_idleReason, opt_broadcast, opt_requestId, opt_broadcastStatusCustomData) {
        var b = (null == opt_broadcast) || opt_broadcast;

        if ((opt_broadcastStatusCustomData || opt_requestId) && !b){
            throw Error("customData and requestId should only be provided in broadcast mode");
        }
        if(this.mediaInformation){
            if(this.media){
                this.media.reset();
            }else{
                this.logger.info("Resetting media element");
                this.mediaElement.removeAttribute("src");
                this.loadTime = 0;
                this.mediaElement.load();
                if(opt_idleReason){
                    this.idleReason = opt_idleReason;
                }
                this.oMediaInformation = this.mediaInformation;
                this.mediaInformation = null;
                if(b){
                    this.broadcastStatus(!1, opt_requestId, opt_broadcastStatusCustomData);
                }
            }
        }else{
            this.logger.info("Nothing to reset, Media is already null");
        }
        b = null;
    };

    /**
     * @name MediaManager#onPause
     * @desc Processes the pause event. The default behavior is to call the media element's pause method and broadcast the status providing the incoming requestId.
     * @param event
     * @method MediaManager#onPause
     */
    MediaManager.prototype.onPause = function (event) {
        if (this.media) {
            this.media.pause()
        } else {
            this.mediaElement.pause();
        }
        this.broadcastStatus(false, event.data.requestId);
    };

    /**
     * @name MediaManager#onSetVolume
     * @desc Processes the set volume event. The default behavior is to set volume and muted on the media element as required and broadcast the status providing the incoming requestId.
     * @param event
     * @method MediaManager#onSetVolume
     */
    MediaManager.prototype.onSetVolume = function (event) {
        a = event.data;
        if (this.media) {
            this.media.setVolume(a.volume)
        } else {
            if (0 != a.volume.level) {
                this.mediaElement.volume = a.volume.level;
            }
            if (0 != a.volume.muted) {
                this.mediaElement.muted = a.volume.muted;
            }
        }
        this.broadcastStatus(false, a.requestId);
    };

    /**
     * @name MediaManager#disposeInternal
     * @desc dispose internal1
     * @private
     * @method MediaManager#disposeInternal
     */
    MediaManager.prototype.disposeInternal = function () {
        MediaManager.superClass_.disposeInternal.call(this);
        this.logger.finer("Disposed " + this.getDebugString());
    };

    /**导出符号**/
    /**
     * @name cast.receiver.VERSION
     * @desc Version of the cast SDK.
     * @field
     */
    goog.exportSymbol("cast.receiver.VERSION", "2.0.0");
    goog.exportSymbol("cast.receiver.logger", logger);
    goog.exportSymbol("cast.receiver.LoggerLevel", {
        DEBUG: 0,
        VERBOSE: 400,
        INFO: 800,
        ERROR: 1000,
        NONE: 1500});
    goog.exportSymbol("cast.receiver.CastChannel", CastChannel);
    goog.exportSymbol("cast.receiver.system.NAMESPACE_PREFIX", "urn:x-cast:");
    goog.exportSymbol("cast.receiver.system.ApplicationData", function () {
        this.name = "";
        this.id = "";
        this.sessionId = 0;
        this.namespaces = [];
        this.launchingSenderId = "";});
    goog.exportSymbol("cast.receiver.system.Sender", function () {
        this.userAgent = "";
        this.id = "";});
    goog.exportSymbol("cast.receiver.CastMessageBus", CastMessageBus);
    goog.exportSymbol("cast.receiver.CastReceiverManager", CastReceiverManager);
    goog.exportSymbol("cast.receiver.media.MEDIA_NAMESPACE", "urn:x-cast:com.google.cast.media");
    goog.exportSymbol("cast.receiver.media.StreamType", {
        BUFFERED: "BUFFERED",
        LIVE: "LIVE",
        NONE: "NONE"});
    goog.exportSymbol("cast.receiver.media.ErrorType", MediaErrorType);
    goog.exportSymbol("cast.receiver.media.ErrorReason", {
        INVALID_COMMAND: "INVALID_COMMAND",
        INVALID_PARAMS: "INVALID_PARAMS",
        INVALID_MEDIA_SESSION_ID: "INVALID_MEDIA_SESSION_ID",
        DUPLICATE_REQUEST_ID: "DUPLICATE_REQUEST_ID"});
    goog.exportSymbol("cast.receiver.media.IdleReason", {
        CANCELLED: "CANCELLED",
        INTERRUPTED: "INTERRUPTED",
        FINISHED: "FINISHED",
        ERROR: "ERROR"});
    goog.exportSymbol("cast.receiver.media.SeekResumeState", {
        Rb: "PLAYBACK_START",
        Qb: "PLAYBACK_PAUSE"});
    goog.exportSymbol("cast.receiver.media.PlayerState", {
        IDLE: "IDLE",
        PLAYING: "PLAYING",
        PAUSED: "PAUSED",
        BUFFERING: "BUFFERING"});
    goog.exportSymbol("cast.receiver.media.MediaInformation", MediaInformation);
    goog.exportSymbol("cast.receiver.media.Volume", Volume);
    goog.exportSymbol("cast.receiver.media.MediaStatus", MediaStatus);
    goog.exportSymbol("cast.receiver.media.Command", Command);
    goog.exportSymbol("cast.receiver.MediaManager", MediaManager);
}).call(window);
