/**
 * Copyright (C) 2013-2014, Infthink (Beijing) Technology Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.ß
 */
goog.provide('fling.receiver');

goog.require("goog.debug");
goog.require("goog.debug.Logger");
goog.require("goog.debug.Console");
goog.require("goog.debug.RelativeTimeProvider");
goog.require("goog.debug.HtmlFormatter");
goog.require("goog.events");
goog.require("goog.events.EventTarget");
goog.require("goog.object");
goog.require("goog.reflect");
goog.require("goog.net.WebSocket");
goog.require("goog.dispose");
goog.require('goog.crypt.base64');
goog.require('goog.Timer');

(function () {
    'use strict';
    Function.prototype.bind = Function.prototype.bind || function (a, b) {
        if (1 < arguments.length) {
            var c = Array.prototype.slice.call(arguments, 1);
            c.unshift(this, a);
            return goog.bind.apply(null, c)
        }
        return goog.bind(this, a)
    };

    /**
     * The Fling receiver logger object
     *
     *      Usages:
     *      fling.receiver.logger.setLevelValue(1000)
     *
     * @class fling.receiver.logger
     */
    var logger = goog.debug.Logger.getLogger("fling");

    /**
     * set the log verbosity level.
     *
     * @method setLevelValue
     * @static
     * @param {number} value The logging level.
     * @example
     *      fling.receiver.logger.setLevelValue(1000)
     */
    logger.setLevelValue = function(value){
        logger.setLevel(goog.debug.Logger.Level.getPredefinedLevelByValue(value));
    };
    logger.setLevel(1000);

    /**
     * Handles fling messages for a specific sender and namespace (it is a point to point communications channel).
     * <p>
     * It should be used when the application wants to have a virtual connection with a single sender for a specific protocol (namespace), similar to a virtual websocket. Applications should never create FlingChannels, they should only be obtained from the corresponding FlingMessageBus calling the getFlingChannel method.
     * </p>
     *
     * @class fling.receiver.FlingChannel
     * @constructor
     * @extends goog.events.EventTarget
     * @param {String} msgBus Message bus
     * @param {String} senderId Sender ID
     */
    var FlingChannel = function (msgBus, senderId) {
        goog.events.EventTarget.call(this);
        this.senderId = senderId;
        this.sockOpened = true;
        this.msgBus = msgBus;
        this.onClose = null;
        this.onMessage = null;

        // 注册消息通道中 senderId 上的消息派发
        goog.events.listen(this.msgBus, this.senderId, this.dispatchMessage, false, this);
    };
    goog.inherits(FlingChannel, goog.events.EventTarget);

    /**
     * System events dispatched by fling.receiver.FlingChannel.
     *
     * @property {Object} EventType
     * @property {string} [EventType.MESSAGE="message"] Fired when there is a new message.
     * @property {string} [EventType.CLOSE="close"] Fired when the sender associated with this fling channel has disconnected.
     * @static
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.EventType = {
        MESSAGE: "message",
        CLOSE: "close"
    };

    /**
     * Fling channel event
     *
     * @event FlingChannelEvent
     * @extends goog.events.Event
     * @param {String} type event type
     * @param {String} msg message
     * @for fling.receiver
     * @private
     */
    var FlingChannelEvent = function (type, msg) {
        goog.events.Event.call(this, type);
        this.message = msg;
    };
    goog.inherits(FlingChannelEvent, goog.events.Event);

    /**
     * Event raised by the FlingChannel.
     *
     * @event event
     * @type {FlingChannelEvent}
     * @static
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.Event = FlingChannelEvent;

    /**
     * logger of FlingChannel
     *
     * @method logger
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.prototype.logger = goog.debug.Logger.getLogger("fling.receiver.FlingChannel");

    /**
     * get debug string with senderId and messagebus's namespace for FlingChannel
     *
     * @method getDebugString
     * @return {String} debug string
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.prototype.getDebugString = function () {
        return "FlingChannel[" + this.senderId + " " + this.msgBus.getNamespace() + "]";
    };

    /**
     * The namespace for this FlingChannel.
     *
     * @method getNamespace
     * @return {String} namespace
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.prototype.getNamespace = function () {
        return this.msgBus.getNamespace();
    };

    /**
     * The senderId for this FlingChannel.
     *
     * @method getSenderId
     * @return {string} sender id
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.prototype.getSenderId = function () {
        return this.senderId;
    };

    /**
     * Dispatch FlingChannelEvent message to corresponding handler
     *
     * @method dispatchMessage
     * @param message
     * @private
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.prototype.dispatchMessage = function (message) {
        this.logger.finer("Dispatching FlingChannel message [" + this.msgBus.getNamespace() + ", " + this.senderId + "]: " + message.data);
        var event = new FlingChannelEvent("message", message.data);
        if (this.onMessage) {
            this.onMessage(event);
        }
        this.dispatchEvent(event);
    };

    /**
     * Dispatch close event, and close event object will be disposed after dispatched
     *
     * @method close
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.prototype.close = function () {
        if (this.sockOpened) {
            this.sockOpened = false;
            this.logger.info("Closing FlingChannel [" + this.msgBus.getNamespace() + ", " + this.senderId + "]");
            var event = new FlingChannelEvent("close", this.senderId);
            if (this.onClose) {
                this.onClose(event);
            }
            this.dispatchEvent(event);
            this.dispose();
        }
    };

    /**
     * Sends a message to the sender associated with this FlingChannel.
     *
     * @method send
     * @param message {string} message to send
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.prototype.send = function (message) {
        if (!this.sockOpened) {
            throw Error("Invalid state, socket not open");
        }
        this.msgBus.send(this.senderId, message);
    };

    /**
     * dispose internal
     *
     * @method disposeInternal
     * @private
     * @for fling.receiver.FlingChannel
     */
    FlingChannel.prototype.disposeInternal = function () {
        FlingChannel.superClass_.disposeInternal.call(this);
        this.logger.finer("Disposed " + this.getDebugString());
    };

    /**
     * IpcChannel internal use only
     *
     * @extends goog.events.EventTarget
     */
    var IpcChannel = function () {
        goog.events.EventTarget.call(this);
        this.ws = new goog.net.WebSocket(true);
        this.addOnDisposeCallback(goog.partial(goog.dispose, this.ws));
        goog.events.listen(this.ws, goog.net.WebSocket.EventType.OPENED, this.onWsOpen, false, this);
        goog.events.listen(this.ws, goog.net.WebSocket.EventType.CLOSED, this.onWsClose, false, this);
        goog.events.listen(this.ws, goog.net.WebSocket.EventType.ERROR, this.onWsError, false, this);
        goog.events.listen(this.ws, goog.net.WebSocket.EventType.MESSAGE, this.onWsMessage, false, this);
    };
    goog.inherits(IpcChannel, goog.events.EventTarget);

    /**
     * system event
     *
     * @event SystemEvent
     * @extends goog.events.Event
     * @param type
     * @param senderId
     * @param data
     * @for fling.receiver
     * @private
     */
    var SystemEvent = function (type, senderId, data) {
        goog.events.Event.call(this, type);
        this.senderId = senderId;
        this.data = data;
    };
    goog.inherits(SystemEvent, goog.events.Event);

    /**
     * logger function of IpcChannel
     *
     * @method logger
     * @private
     */
    IpcChannel.prototype.logger = goog.debug.Logger.getLogger("fling.receiver.IpcChannel");

    /**
     * Dispatch system event
     *
     * @method dispatchSystemEvent
     * @param type {string} system type event
     * @private
     */
    IpcChannel.prototype.dispatchSystemEvent = function (type) {
        this.logger.fine("IpcChannel " + type);
        this.dispatchEvent(new SystemEvent("urn:x-cast:com.google.cast.system", "SystemSender", JSON.stringify({ type: type })));
    };

    /**
     * dispatch websocket opened event
     *
     * @method onWsOpen
     * @private
     */
    IpcChannel.prototype.onWsOpen = function () {
        this.dispatchSystemEvent("opened");
    };

    /**
     * dispatch websocket closed event
     * @method onWsClose
     * @private
     */
    IpcChannel.prototype.onWsClose = function () {
        this.dispatchSystemEvent("closed");
    };

    /**
     * dispatch websocket error event
     *
     * @method onWsError
     * @private
     */
    IpcChannel.prototype.onWsError = function () {
        this.dispatchSystemEvent("error");
    };

    /**
     * dispatch websocket message received event
     *
     * @method onWsMessage
     * @param wsMsg {Object} websockt message
     * @private
     */
    IpcChannel.prototype.onWsMessage = function (wsMsg) {
        this.logger.fine("Received message: " + wsMsg.message);
        var msg = JSON.parse(wsMsg.message);
        var ns = msg && msg.namespace;
        if (msg && ns && msg.senderId && msg.data) {
            this.dispatchEvent(new SystemEvent(ns, msg.senderId, msg.data));
        } else {
            this.logger.severe("IpcChannel Message received is invalid");
        }
    };

    /**
     * open IpcChannel
     *
     * @method open
     * @private
     */
    IpcChannel.prototype.open = function () {
        this.logger.info("Opening message bus websocket");
        this.ws.open("ws://localhost:8008/v2/ipc");
    };

    /**
     * close IpcChannel
     *
     * @method close
     * @private
     */
    IpcChannel.prototype.close = function () {
        this.logger.info("Closing message bus websocket");
        this.ws.close();
    };

    /**
     * whether websocket is opened
     *
     * @method isOpen
     * @private
     */
    IpcChannel.prototype.isOpen = function () {
        return this.ws.isOpen();
    };

    /**
     * send data
     *
     * @method send
     * @param ns
     * @param senderId
     * @param data
     * @private
     */
    IpcChannel.prototype.send = function (ns, senderId, data) {
        if (!this.isOpen()) {
            throw Error("Underlying websocket is not open");
        }

        var msg = JSON.stringify({
            namespace: ns,
            senderId: senderId,
            data: data
        });
        this.logger.fine("IPC message sent: " + msg);
        this.ws.send(msg);
    };

    /**
     * dispose internal
     *
     * @method disposeInternal
     * @private
     */
    IpcChannel.prototype.disposeInternal = function () {
        IpcChannel.superClass_.disposeInternal.call(this);
        this.logger.finer("Disposed IpcChannel");
    };

    /**
     * Handles fling messages for a specific namespace
     * <p>
     *     Applications should never create a FlingMessageBus, they should only be obtained from the fling.receiver.FlingReceiverManager instance. Extends goog.events.EventTarget. Implements EventTarget.
     * </p>
     *
     * @class fling.receiver.FlingMessageBus
     * @constructor
     * @param ns {String} namespace
     * @param ipcChannel {String} ipc channel
     * @param c
     * @param messageType {String} message type
     * @extends goog.events.EventTarget
     */
    var FlingMessageBus = function (ns, ipcChannel, c, messageType) {
        goog.events.EventTarget.call(this);
        this.ns = ns;
        this.ipcChannel = ipcChannel;
        this.messageType = messageType || "STRING";
        this.onMessage = null;
        this.channels = {};
        for (var i = 0; i < c.length; i++) {
            this.channels[c[i]] = null;
        }
        goog.events.listen(this.ipcChannel, this.ns, this.dispatchMessage, false, this)
    };
    goog.inherits(FlingMessageBus, goog.events.EventTarget);

    /**
     * Message types used by fling.receiver.FlingMessageBus.
     *
     * @property {Object} MessageType
     * @property {string} MessageType.STRING="STRING" Messages are CUSTOM-encoded. The application must implement its own fling.receiver.FlingMessageBus.prototype.serializeMessage and fling.receiver.FlingMessageBus.prototype.deserializeMessage
     * @property {string} MessageType.JSON="JSON" Messages are JSON-encoded. The underlying transport will use a JSON encoded string.
     * @property {string} MessageType.CUSTOM="CUSTOM" Messages are free-form strings. The application is responsible for encoding/decoding the information transmitted.
     * @type {{STRING: string, JSON: string, CUSTOM: string}}
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.MessageType = {
        STRING: "STRING",
        JSON: "JSON",
        CUSTOM: "CUSTOM"
    };

    /**
     * Event type
     *
     * @property {Object} EventType
     * @type {{MESSAGE: string}}
     * @property {string} EventType.MESSAGE="message" Fired when there is a message.
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.EventType = {
        MESSAGE: "message"
    };

    /**
     * Event raised when a new message is received on the message bus for a specific namespace.
     *
     * @event FlingMessageBusEvent
     * @param type event type
     * @param senderId The sender Id.
     * @param data {*} Application message.
     * @extends goog.events.Event
     * @for fling.receiver
     * @private
     */
    var FlingMessageBusEvent = function (type, senderId, data) {
        goog.events.Event.call(this, type);
        this.senderId = senderId;
        this.data = data
    };
    goog.inherits(FlingMessageBusEvent, goog.events.Event);


    /**
     * Event raised when a new message is received on the message bus for a specific namespace.
     *
     * @event Event
     * @type {FlingMessageBusEvent}
     * @for fling.receiver.FlingMessageBus
     * @static
     */
    FlingMessageBus.Event = FlingMessageBusEvent;

    /**
     * logger for FlingMessageBus
     *
     * @method logger
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.prototype.logger = goog.debug.Logger.getLogger("fling.receiver.FlingMessageBus");

    /**
     * get fling message bus debug message string for FlingMessageBus
     *
     * @method getDebugString
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.prototype.getDebugString = function () {
        return "FlingMessageBus[" + this.ns + "]"
    };

    /**
     * The namespace of the messages processed by this FlingMessageBus.
     *
     * @method getNamespace
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.prototype.getNamespace = function () {
        return this.ns;
    };

    /**
     * The type of messages processed by this FlingMessageBus.
     *
     * @method getMessageType
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.prototype.getMessageType = function () {
        return this.messageType;
    };

    /**
     * dispatch message on FlingMessageBus
     *
     * @method dispatchMessage
     * @param message
     * @for fling.receiver.FlingMessageBus
     * @private
     */
    FlingMessageBus.prototype.dispatchMessage = function (message) {
        this.logger.finer("Dispatching FlingMessageBus message [" + this.ns + ", " + message.senderId + "]: " + message.data);

        var data = ("STRING" == this.messageType) ? message.data : this.deserializeMessage(message.data);

        this.dispatchEvent(new FlingMessageBusEvent(message.senderId, message.senderId, data));

        var event = new FlingMessageBusEvent("message", message.senderId, data);

        if (this.onMessage) {
            this.onMessage(event);
        }

        this.dispatchEvent(event)
    };

    /**
     * Sends a message to a specific sender.
     *
     * @method send
     * @param senderId
     * @param message
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.prototype.send = function (senderId, message) {
        if ("STRING" == this.messageType) {
            if (!goog.isString(message)) {
                throw Error("Wrong argument, FlingMessageBus type is STRING");
            }
            this.ipcChannel.send(this.ns, senderId, message)
        } else {
            this.ipcChannel.send(this.ns, senderId, this.serializeMessage(message))
        }
    };

    /**
     * Sends a message to all the senders connected.
     *
     * @method broadcast
     * @param message
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.prototype.broadcast = function (message) {
        this.send("*:*", message)
    };

    /**
     * Provides a {fling.receiver.FlingChannel} for a specific senderId.
     *
     * @method getFlingChannel
     * @param senderId
     * @return {*}
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.prototype.getFlingChannel = function (senderId) {
        if (senderId in this.channels) {
            if (!this.channels[senderId]) {
                this.channels[senderId] = new FlingChannel(this, senderId);
            }
            return this.channels[senderId];
        }
        throw Error("Requested a socket for a disconnected sender: " + senderId);
    };

    /**
     * Serializes a deserialized message.
     *
     * @method serializeMessage
     * @param message
     * @return {*}
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.prototype.serializeMessage = function (message) {
        if ("JSON" != this.messageType) {
            throw Error("Unexpected message type for JSON serialization");
        }
        return JSON.stringify(message)
    };

    /**
     * Deserializes a serialized message.
     *
     * @method deserializeMessage
     * @param message
     * @return {*}
     * @for fling.receiver.FlingMessageBus
     */
    FlingMessageBus.prototype.deserializeMessage = function (message) {
        if ("JSON" != this.messageType) {
            throw Error("Unexpected message type for JSON serialization");
        }
        return JSON.parse(message)
    };

    /**
     * dispose internal
     *
     * @method disposeInternal
     * @for fling.receiver.FlingMessageBus
     * @private
     */
    FlingMessageBus.prototype.disposeInternal = function () {
        FlingMessageBus.superClass_.disposeInternal.call(this);
        if (this.channels) {
            for (var i in this.channels) {
                if (this.channels[i]) {
                    this.channels[i].close();
                }
            }
            this.channels = {}
        }
        this.logger.finer("Disposed " + this.getDebugString());
    };

    var inactivity_config = {
        statusText: void 0,
        maxInactivity: 10 //最大空闲时间
    };

    /**
     * Initializes the system manager so we can communicate with the platform.
     * <p>
     *     This class is used to send/receive system messages/events. It must only be instantiated just once (singleton). Extends goog.events.EventTarget. Implements EventTarget.
     * </p>
     * @class fling.receiver.FlingReceiverManager
     * @constructor
     * @extends goog.events.EventTarget
     */
    var FlingReceiverManager = function () {
        goog.events.EventTarget.call(this);

        if (this.console = new goog.debug.Console) {
            this.console.setCapturing(true);

            // var console = this.console;
            // if (!console.isCapturing_) {

                // goog.debug.LogManager.initialize();
                // var flingReceiverManagerLogger = logger,
                //     c = console.publishHandler_;
                // flingReceiverManagerLogger.rootHandlers_ || (flingReceiverManagerLogger.rootHandlers_ = []);
                // flingReceiverManagerLogger.rootHandlers_.push(c);
            // }
        }

        this.inactivity_config = goog.object.clone(inactivity_config);
        this.ipcChannel = new IpcChannel;
        this.senders = {};
        this.systemSender = new FlingMessageBus("urn:x-cast:com.google.cast.system", this.ipcChannel, goog.object.getKeys(this.senders), "JSON");
        this.heartbeatSender = new FlingMessageBus("urn:x-cast:com.google.cast.tp.heartbeat", this.ipcChannel, goog.object.getKeys(this.senders), "JSON");

        this.addOnDisposeCallback(goog.partial(goog.dispose, this.systemSender));

        this.started = false;
        this.systemReady = false;
        this.messageBusList = {};

        this.onVisibilityChanged = null;
        this.onSystemVolumeChanged = null;
        this.onMediaVolumeChanged = null;
        this.onSenderDisconnected = null;
        this.onSenderConnected = null;
        this.onReady = null;

        goog.events.listen(this.systemSender, "SystemSender", this.listenerCallback, false, this);
        goog.events.listen(this.heartbeatSender, "HeartbeatSender", this.heartbeatCallback, false, this);
    };
    goog.inherits(FlingReceiverManager, goog.events.EventTarget);

    /**
     * get receiver manager instance.
     *
     * @method getInstance
     * @return {FlingReceiverManager|*}
     * @for fling.receiver.FlingReceiverManager
     * @static
     */
    FlingReceiverManager.getInstance = function () {
        if (!FlingReceiverManager.instance) {
            FlingReceiverManager.instance = new FlingReceiverManager;
        }
        return FlingReceiverManager.instance;
    };

    /**
     * event type for FlingReceiverManager
     *
     * @property {Object} EventType
     * @type {{OPENED: string, CLOSED: string, READY: string, SHUTDOWN: string, SENDER_CONNECTED: string, SENDER_DISCONNECTED: string, ERROR: string, SYSTEM_VOLUME_CHANGED: string, VISIBILITY_CHANGED: string}}
     * @property EventType.OPENED="opened" {string} Fired when the application is opened.
     * @property EventType.CLOSED="closed" {string} ired when the application is closed.
     * @property EventType.READY="ready" {string} Fired when the system is ready.
     * @property EventType.SHUTDOWN="shotdown" {string} Fired when the application is terminated.
     * @property EventType.SENDER_CONNECTED="senderconnected" {string} Fired when a new sender has connected.
     * @property EventType.SENDER_DISCONNECTED="senderdisconnected" {string} Fired when a sender has disconnected.
     * @property EventType.ERROR="error" {string} Fired when there is a system error.
     * @property EventType.SYSTEM_VOLUME_CHANGED="systemvolumechanged" {string} Fired when the system volume has changed.
     * @property EventType.VISIBILITY_CHANGED="visibilitychanged" {string} Fired when the visibility of the application has changed (for example after a HDMI Input change or when the TV is turned off/on and the fling device is externally powered). Note that this API has the same effect as the webkitvisibilitychange event raised by your document, we provided it as FlingReceiverManager API for convenience and to avoid a dependency on a webkit-prefixed event.
     * @for fling.receiver.FlingReceiverManager
     * @static
     */
    FlingReceiverManager.EventType = {
        OPENED: "opened",
        CLOSED: "closed",
        READY: "ready",
        SHUTDOWN: "shutdown",
        SENDER_CONNECTED: "senderconnected",
        SENDER_DISCONNECTED: "senderdisconnected",
        ERROR: "error",
        SYSTEM_VOLUME_CHANGED: "systemvolumechanged",
        VISIBILITY_CHANGED: "visibilitychanged"
    };

    /**
     * Event dispatched by fling.receiver.FlingReceiverManager which contains system information.
     *
     * @event DataEvent
     * @param type event type
     * @param data Data associated with this event.
     * @extends goog.events.Event
     */
    var DataEvent = function (type, data) {
        goog.events.Event.call(this, type);
        this.data = data
    };
    goog.inherits(DataEvent, goog.events.Event);

    /**
     * Event dispatched by fling.receiver.FlingReceiverManager which contains system information.
     *
     * @event Event
     * @type {DataEvent}
     * @for fling.receiver.FlingReceiverManager
     * @static
     */
    FlingReceiverManager.Event = DataEvent;

    /**
     * Application configuration parameters.
     *
     * @method Config
     * @static
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.Config = function () {
        /*
         * Maximum time in seconds before closing an idle sender connection.
         */
        this.maxInactivity = null;
        /* Text that represents the application status. */
        this.statusText = null;
    };

    /**
     * logger of FlingReceiverManager
     *
     * @method logger
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.logger = goog.debug.Logger.getLogger("fling.receiver.FlingReceiverManager");

    /**
     * get debug string of FlingReceiverManager
     *
     * @method getDebugString
     * @return {string}
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.getDebugString = function () {
        return "FlingReceiverManager"
    };

    /**
     * Initializes the system manager. The application should call this method when it is ready to start receiving messages, typically after registering to listen for the events it is interested on.
     *
     * @method start
     * @param config {FlingReceiverManager.Config} config data
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.start = function (config) {
        if (config) {
            if (!config) {
                throw Error("Cannot validate undefined config.");
            }

            if (config.maxInactivity != void 0 && config.maxInactivity < 5) {
                throw Error("config.maxInactivity must be greater than or equal to 5 seconds.");
            }

            goog.object.extend(this.inactivity_config, config || {})
        }
        this.started = true;
        this.ipcChannel.open();
    };

    /**
     * Terminates the application. It can be called by the application to kill itself, it has to be the last method called.
     *
     * @method stop
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.stop = function () {
        //this.G();
        window.close()
    };

    /**
     * When the application calls start, the system will send the ready event to indicate that the application information is ready and the application can send messages as soon as there is one sender connected.
     *
     * @method isSystemReady
     * @return {boolean|*} Whether or not the system is ready to process messages.
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.isSystemReady = function () {
        return this.systemReady
    };

    /**
     * Provides a list of the senders currently connected to the application. Must not be null.
     *
     * @method getSenders
     * @return {*} The list of senderIds connected to the application. Must not be null.
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.getSenders = function () {
        //getKeys
        return goog.object.getKeys(this.senders)
    };

    /**
     * Provides a copy of the sender object by senderId.
     *
     * @method getSender
     * @param senderId {String} SenderId of the connected sender.
     * @return {*} Sender object or null if not found.
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.getSender = function (senderId) {
        if (this.senders[senderId] != null) {
            return goog.object.clone(this.senders[senderId]);
        }
        return null;
    };

    /**
     * Provides application information once the system is ready, otherwise it will be null.
     *
     * @method getApplicationData
     * @return {{id: *, name: *, sessionId: *, namespaces: *, launchingSenderId: *}|*} The application information.
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.getApplicationData = function () {
        return this.appData
    };

    /**
     * Sets the application state. The application should call it when its state changes.
     *
     * @method setApplicationState
     * @param statusText {string} The status text.
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.setApplicationState = function (statusText) {
        if (this.systemReady) {
            var message = {
                type: "setappstate"
            };

            if (statusText != null) {
                message.statusText = statusText;
            }

            this.systemSender.send("SystemSender", message);

        } else {
            this.inactivity_config.statusText = statusText;
        }
    };

    /**
     * Provides a channel for a specific namespace (for any sender).Must not be null.
     *
     * @method getFlingMessageBus
     * @param ns {string} The namespace. Note that a valid namespace has to be prefixed with the string 'urn:x-cast:'.
     * @param messageType {FlingMessageBus.MessageType} The type of messages supported by the namespace. Optional.
     * @return {*} The namespace channel. Must not be null.
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.getFlingMessageBus = function (ns, messageType) {
        if (ns == "urn:x-cast:com.google.cast.system") {
            throw Error("Protected namespace");
        }

        if (0 != ns.lastIndexOf("urn:x-cast:", 0)) {
            throw Error("Invalid namespace prefix");
        }

        if (!this.messageBusList[ns]) {
            if (this.started) {
                throw Error("New namespaces can not be requested after start has been called");
            }
            this.messageBusList[ns] = new FlingMessageBus(ns, this.ipcChannel, goog.object.getKeys(this.senders), messageType);

            this.addOnDisposeCallback(goog.partial(goog.dispose, this.messageBusList[ns]))
        }

        if (messageType && this.messageBusList[ns].getMessageType() != messageType) {
            throw Error("Invalid messageType for the namespace");
        }

        return this.messageBusList[ns]
    };

    /**
     * heartbeat callback, used internal
     *
     * @method heartbeatCallback
     * @param message
     * @private
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.heartbeatCallback = function (message) {
        var data = message.data;
        if ("PING" == data.type) {
            message = {type : "PONG"};
            this.heartbeatSender.send("HeartbeatSender", message);
        } else if ("PONG" == data.type) {
            message = {type : "PING"};
            this.heartbeatSender.send("HeartbeatSender", message);
        }
    };

    /**
     * listener callback, used internal
     *
     * @method listenerCallback
     * @param message
     * @private
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.listenerCallback = function (message) {
        var dataEvent,
            b = message.data; //FlingMessageBus

        this.logger.finer("FlingReceiverManager message received: " + message.data);
        switch (b.type) {
            case FlingReceiverManager.EventType.OPENED:
                this.logger.info("Underlying message bus is open");

                message = { type: "ready" };

                if (this.inactivity_config.statusText) {
                    message.statusText = this.inactivity_config.statusText;
                }

                message.activeNamespaces = goog.object.getKeys(this.messageBusList);
                message.version = "2.0.0";
                message.messagesVersion = "1.0";
                this.systemSender.send("SystemSender", message);

                this.inactivity_config.maxInactivity && this.systemSender.send("SystemSender", {
                    type: "startheartbeat",
                    maxInactivity: this.inactivity_config.maxInactivity,
                    fling: true
                });
                break;

            case FlingReceiverManager.EventType.CLOSED:
                this.systemReady = false;
                this.dispatchEvent("shutdown");
                break;

            case FlingReceiverManager.EventType.ERROR:
                this.dispatchEvent("error");
                break;

            case FlingReceiverManager.EventType.READY:
                this.appData = {
                    id: b.applicationId,
                    name: b.applicationName,
                    sessionId: b.sessionId,
                    namespaces: goog.object.getKeys(this.messageBusList),
                    launchingSenderId: b.launchingSenderId
                };
                this.systemReady = true;
                this.logger.info("Dispatching FlingReceiverManager system ready event [" + this.appData + "]");
                var event = new DataEvent("ready", this.appData);
                if (this.onReady) {
                    this.onReady(event);
                }
                this.dispatchEvent(event);
                break;

            case FlingReceiverManager.EventType.SENDER_CONNECTED:
                var d = {
                    id: b.senderId,
                    userAgent: b.userAgent
                };
                this.logger.info("Dispatching FlingReceiverManager sender connected event [" + d.id + "]");
                if(d.id in this.senders){
                    this.logger.severe("Unexpected connected message for already connected sender: " + d.id);
                }
                
                this.senders[d.id] = d;
                dataEvent = new DataEvent("senderconnected", d.id);
                for (c in this.messageBusList) {
                    var messageBus = this.messageBusList[c];
                    if(d.id in messageBus.channels){
                        messageBus.logger.severe("Unexpected sender already registered [" + messageBus.ns + ", " + d.id + "]");
                    }else{
                        messageBus.logger.info("Registering sender [" + messageBus.ns + ", " + d.id + "]");
                        messageBus.channels[d.id] = null;
                    }
                }
                if (this.onSenderConnected){
                    this.onSenderConnected(dataEvent);
                } 
                this.dispatchEvent(dataEvent);
                break;

            case FlingReceiverManager.EventType.SENDER_DISCONNECTED:
                var c = b.senderId;
                this.logger.info("Dispatching sender disconnected event [" + c + "]");
                if (c in this.senders) {
                    delete this.senders[c];
                    dataEvent = new DataEvent("senderdisconnected", c);
                    for (d in this.messageBusList) {
                        b = this.messageBusList[d];
                        var e = c;
                        if(e in b.channels){
                            b.logger.info("Unregistering sender [" + b.ns + ", " + e + "]"), 
                            b.channels[e] && b.channels[e].close(), 
                            delete b.channels[e];
                        }
                    }

                    if (this.onSenderDisconnected) {
                        this.onSenderDisconnected(dataEvent);
                    }

                    this.dispatchEvent(dataEvent)
                } else this.logger.severe("Unknown sender disconnected: " + c);
                break;

            case FlingReceiverManager.EventType.SYSTEM_VOLUME_CHANGED:
                var c = {
                    level: b.level,
                    muted: b.muted
                };
                this.logger.info("Dispatching system volume changed event [" + c.level + ", " + c.muted + "]");
                dataEvent = new DataEvent("systemvolumechanged", c);
                if (this.onSystemVolumeChanged) this.onSystemVolumeChanged(dataEvent);
                this.dispatchEvent(dataEvent);
                break;

            case FlingReceiverManager.EventType.VISIBILITY_CHANGED:
                var c = b.visible;
                this.logger.info("Dispatching visibility changed event " + c);
                dataEvent = new DataEvent("visibilitychanged", c);
                if (this.onVisibilityChanged){
                    this.onVisibilityChanged(c);
                }
                this.dispatchEvent(c);
                break;

            default:
                throw Error("Unexpected message type: " + b.type);
        }
    };

    /**
     * dispose event internal
     *
     * @method disposeInternal
     * @private
     * @for fling.receiver.FlingReceiverManager
     */
    FlingReceiverManager.prototype.disposeInternal = function () {
        FlingReceiverManager.superClass_.disposeInternal.call(this);
        delete FlingReceiverManager.instance;
        this.logger.fine("Disposed " + this.getDebugString());
    };

    /**
     * @property {Object} ErrorType
     * @property ErrorType.INVALID_PLAYER_STATE="INVALID_PLAYER_STATE" {String}
     * @property ErrorType.LOAD_FAILED="LOAD_FAILED" {String}
     * @property ErrorType.LOAD_CANCELLED="LOAD_CANCELLED" {String}
     * @property ErrorType.INVALID_REQUEST="INVALID_REQUEST" {String}
     * @type {{INVALID_PLAYER_STATE: string, LOAD_FAILED: string, LOAD_CANCELLED: string, INVALID_REQUEST: string}}
     * @for fling.receiver.media
     * @static
     */
    var MediaErrorType = {
        INVALID_PLAYER_STATE: "INVALID_PLAYER_STATE",
        LOAD_FAILED: "LOAD_FAILED",
        LOAD_CANCELLED: "LOAD_CANCELLED",
        INVALID_REQUEST: "INVALID_REQUEST"
    };

    /**
     * Represents the media information.
     *
     * @class fling.receiver.media.MediaInformation
     * @constructor
     */
    var MediaInformation = function () {
        this.contentId = "";
        this.streamType = "NONE";
        this.contentType = "";
        this.customData = null;
        this.duration = null;
        this.metadata = null;
    };

    /**
     * Represents the volume of a media session stream.
     *
     * @class fling.receiver.media.Volume
     * @constructor
     */
    var Volume = function () {
        this.muted = this.level = void 0
    };

    /**
     * Represents the status of a media session.
     *
     * @class fling.receiver.media.MediaStatus
     * @constructor
     */
    var MediaStatus = function () {
        this.mediaSessionId = 0;
        this.media = void 0;
        this.playbackRate = 1;
        this.playerState = "IDLE";
        this.idleReason = null;
        this.supportedMediaCommands = 0;
        this.currentTime = 0;
        this.volume = {
            level: 0,
            muted: false
        };
        this.customData = null;
    };

    /**
     * Commands supported by fling.receiver.MediaManager.
     *
     * @property {Object} Command
     * @property Command.PAUSE=1 {number} Pause Command.
     * @property Command.SEEK=2 {number} Seek Command.
     * @property Command.STREAM_VOLUME=4 {number} Stream Volume Command.
     * @property Command.STREAM_MUTE=8 {number} Stream Volume Command.
     * @type {{PAUSE: number, SEEK: number, STREAM_VOLUME: number, STREAM_MUTE: number}}
     * @for fling.receiver.media
     * @static
     */
    var Command = {
        PAUSE: 1,
        SEEK: 2,
        STREAM_VOLUME: 4,
        STREAM_MUTE: 8
    };

    /**
     * This class is used to send/receive media messages/events. Extends goog.events.EventTarget. Implements EventTarget.
     *
     * @class fling.receiver.MediaManager
     * @constructor
     * @param mediaElement
     * @param opt_supportedCommands
     * @extends goog.events.EventTarget
     */
    var MediaManager = function (mediaElement, opt_supportedCommands) {
        goog.events.EventTarget.call(this);
        this.flingMessageBus = FlingReceiverManager.getInstance().getFlingMessageBus("urn:x-cast:com.google.cast.media", "JSON");
        this.mediaSessionId = 0; //this.fa
        this.playbackRate = 1; // this.Xa
        this.supportedMediaCommands = opt_supportedCommands || 15; // this.Ya
        
        this.mediaStatusSenderTime = null; // this.Aa
        this.mediaStatusSenderCurrentTime = null; // this.za
        this.currentTime = null; // this.C
        this.loadTime = 0; //this.ea

        this.oMediaInformation = null; // this.W
        this.mediaInformation = null; //MediaInformation
        this.mediaElement = null; //MediaElement<video/audio> this.b
        this.media = null; //this.c

        this.isPlayerBuffering = false; // this.l
        this.idleReason = null; // this.L
        this.loadInfo = null; // this.f

        this.setMediaElement(mediaElement);
        this.flingMessageBus.onMessage = this.onMessage.bind(this);
        goog.Timer.callOnce(goog.bind(this.bufferState, this), 1000);
    };
    goog.inherits(MediaManager, goog.events.EventTarget);

    /**
     * System events dispatched by fling.receiver.MediaManager.
     *
     * @property {Object} EventType
     * @for fling.receiver.MediaManager
     * @property EventType.LOAD="load" {string} Fired when there is a load message.
     * @property EventType.STOP="stop" {string} Fired when there is a stop message.
     * @property EventType.PAUSE="pause" {string} Fired when there is a pause message.
     * @property EventType.PLAY="play" {string} Fired when there is a play message.
     * @property EventType.SEEK="seek" {string} Fired when there is a seek message.
     * @property EventType.SET_VOLUME="setvolume" {string} Fired when there is a set volume message.
     * @property EventType.GET_STATUS="getstatus" {string} Fired when there is a get status message.
     * @type {{LOAD: string, STOP: string, PAUSE: string, PLAY: string, SEEK: string, SET_VOLUME: string, GET_STATUS: string}}
     * @static
     */
    MediaManager.EventType = {
        LOAD: "load",
        STOP: "stop",
        PAUSE: "pause",
        PLAY: "play",
        SEEK: "seek",
        SET_VOLUME: "setvolume",
        GET_STATUS: "getstatus"
    };

    /**
     * media manager event
     *
     * @event MediaManagerEvent
     * @param a
     * @param b
     * @param c
     * @extends goog.events.Event
     * @for fling.receiver
     * @private
     */
    var MediaManagerEvent = function (a, b, c) {
        goog.events.Event.call(this, a);
        this.data = b;
        this.senderId = c
    };
    goog.inherits(MediaManagerEvent, goog.events.Event);

    goog.exportSymbol("fling.receiver.MediaManager", MediaManager);

    /**
     * Event dispatched by fling.receiver.MediaManager which contains system information
     *
     * @event MediaManager.Event
     * @type {MediaManagerEvent}
     * @static
     * @for fling.receiver.MediaManager
     */
    MediaManager.Event = MediaManagerEvent;

    /**
     * request data
     *
     * @method RequestData
     * @for fling.receiver
     * @private
     */
    var RequestData = function () {
        this.requestId = 0;
        this.mediaSessionId = void 0;
        this.customData = null;
    };

    /**
     * Request data associated with this event.
     *
     * @method RequestData
     * @type {RequestData}
     * @static
     * @for fling.receiver.MediaManager
     */
    MediaManager.RequestData = RequestData;

    /**
     * Media event LOAD request data.
     *
     * @method LoadRequestData
     * @extends RequestData
     * @for fling.receiver
     * @private
     */
    var LoadRequestData = function () {
        this.media = new MediaInformation;
        this.autoplay = false;
        this.currentTime = 0;
    };

    goog.inherits(LoadRequestData, RequestData);

    /**
     * Media event LOAD request data.
     *
     * @method LoadRequestData
     * @type {LoadRequestData}
     * @for fling.receiver.MediaManager
     * @static
     */
    MediaManager.LoadRequestData = LoadRequestData;

    /**
     * Media event SET_VOLUME request data
     *
     * @method VolumeRequestData
     * @extends RequestData
     * @for fling.receiver
     * @private
     */
    var VolumeRequestData = function () {
        this.volume = new Volume
    };

    goog.inherits(VolumeRequestData, RequestData);

    /**
     * Media event SET_VOLUME request data.
     *
     * @method VolumeRequestData
     * @type {VolumeRequestData}
     * @static
     * @for fling.receiver.MediaManager
     */
    MediaManager.VolumeRequestData = VolumeRequestData;

    /**
     * Media event SEEK request data
     *
     * @method SeekRequestData
     * @static
     * @for fling.receiver.MediaManager
     */
    MediaManager.SeekRequestData = function () {
        this.resumeState = void 0;
        this.currentTime = 0
    };

    /**
     * Load Request Information
     *
     * @method LoadInfo
     * @param message
     * @param senderId
     * @static
     * @for fling.receiver.MediaManager
     */
    MediaManager.LoadInfo = function (message, senderId) {
        this.message = message;
        this.senderId = senderId;
    };

    /**
     * logger of MediaManager
     *
     * @method logger
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.logger = goog.debug.Logger.getLogger("fling.receiver.MediaManager");

    /**
     * get debug string of MediaManager
     *
     * @method getDebugString
     * @return {string}
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.getDebugString = function () {
        return "MediaManager"
    };

    /**
     * Provides information about the media currently loaded.
     *
     * @method getMediaInformation
     * @return {null|*} The media information.
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.getMediaInformation = function () {
        return this.mediaInformation
    };

    /**
     * Sets information about the media currently loaded. This information will be sent to the senders when they request media status.
     *
     * @method setMediaInformation
     * @param mediaInformation {MediaInformation} The new media information. Use resetMediaElement to reset its value. Must not be null.
     * @param opt_broadcast {boolean} Whether the senders should be notified about the change (if not provided, the senders will be notified). Optional.
     * @param opt_broadcastStatusCustomData {*} If the senders should be notified this parameter allows to set the application-specific custom data in the status message. Optional.
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.setMediaInformation = function (mediaInformation, opt_broadcast, opt_broadcastStatusCustomData) {
        opt_broadcast = void 0 == opt_broadcast || opt_broadcast;
        if (opt_broadcastStatusCustomData && !opt_broadcast){
            throw Error("No broadcast call but status customData has been provided");
        } 
        this.mediaInformation = mediaInformation;
        if(opt_broadcast){
            this.broadcastStatus(!0, null, opt_broadcastStatusCustomData);
        }
    };

    /**
     * received message
     *
     * @method onMessage
     * @param a
     * @private
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onMessage = function (a) {
        var b = a.data;
        a = a.senderId;

        var c = b.type;
        var d = b.requestId;

        if ("number" == typeof d && d == Math.floor(d))
            if (void 0 != b.mediaSessionId && b.mediaSessionId != this.mediaSessionId || "LOAD" != c && "GET_STATUS" != c && ("IDLE" == mediaState(this) || void 0 == b.mediaSessionId)) {
                this.logger.severe("Invalid media session ID: " + b.mediaSessionId);
                this.sendError(a, d, "INVALID_REQUEST", "INVALID_MEDIA_SESSION_ID");
            } else {
                this.logger.finer("MediaManager message received [" + a + "] " + JSON.stringify(b));
                delete b.type;
                var e = null;
                switch (c) {
                    case "LOAD":
                        this.logger.info("Dispatching MediaManager load event");
                        if (b.media) {
                            if (this.loadInfo) {
                                this.sendLoadError("LOAD_CANCELLED")
                            } else if (this.mediaInformation) {
                                this.resetMediaElement("INTERRUPTED");
                            }
                            this.loadInfo = {
                                senderId: a,
                                message: b
                            };
                            this.loadTime = b.currentTime || 0;
                            this.mediaInformation = b.media;
                            this.mediaSessionId++;
                            b = new MediaManagerEvent("load", b, a);
                            if (this.onLoad) {
                                this.onLoad(b);
                            }
                            this.dispatchEvent(b);
                            e = null
                        } else {
                            this.logger.severe("media is mandatory");
                            e = {
                                type: "INVALID_REQUEST",
                                reason: "INVALID_PARAMS"
                            };
                        }
                        break;

                    case "GET_STATUS":
                        this.logger.info("Dispatching MediaManager getStatus event");
                        b = new MediaManagerEvent("getstatus", b, a);
                        if (this.onGetStatus) {
                            this.onGetStatus(b);
                        }
                        this.dispatchEvent(b);
                        e = null;
                        break;

                    case "PLAY":
                        this.logger.info("Dispatching MediaManager play event");
                        b = new MediaManagerEvent("play", b, a);
                        if (this.onPlay) {
                            this.onPlay(b);
                        }
                        this.dispatchEvent(b);
                        e = null;
                        break;

                    case "SEEK":
                        if (void 0 == b.currentTime) {
                            this.logger.severe("currentTime is mandatory");
                            e = {
                                type: "INVALID_REQUEST",
                                reason: "INVALID_PARAMS"
                            };
                        } else {
                            this.logger.info("Dispatching MediaManager seek event");
                            b = new MediaManagerEvent("seek", b, a);
                            if (this.onSeek) {
                                this.onSeek(b);
                            }
                            this.dispatchEvent(b);
                            e = null
                        }
                        break;

                    case "STOP":
                        this.logger.info("Dispatching MediaManager stop event");
                        b = new MediaManagerEvent("stop", b, a);
                        if (this.onStop) {
                            this.onStop(b);
                        }
                        this.dispatchEvent(b);
                        e = null;
                        break;

                    case "PAUSE":
                        this.logger.info("Dispatching MediaManager pause event");
                        b = new MediaManagerEvent("pause", b, a);
                        if (this.onPause) {
                            this.onPause(b);
                        }
                        this.dispatchEvent(b);
                        e = null;
                        break;

                    case "SET_VOLUME":
                        if (!b.volume || void 0 == b.volume.level && void 0 == b.volume.muted) {
                            this.logger.severe("volume is invalid");
                            e = {
                                type: "INVALID_REQUEST",
                                reason: "INVALID_PARAMS"
                            };
                        } else if (b.volume.level < 0 || b.volume.level > 1) {
                            this.logger.severe("volume level is invalid");
                            e = {
                                type: "INVALID_REQUEST",
                                reason: "INVALID_PARAMS"
                            };
                        } else {
                            this.logger.info("Dispatching MediaManager setvolume event");
                            b = new MediaManagerEvent("setvolume", b, a);
                            if (this.onSetVolume) {
                                this.onSetVolume(b);
                            }
                            this.dispatchEvent(b);
                            e = null
                        }
                        break;

                    default:
                        this.logger.severe("Unexpected message type: " + c);
                        e = {
                            type: MediaErrorType.INVALID_COMMAND
                        }
                }
                if (e) {
                    this.logger.severe("Sending error: " + e.type + " " + e.reason);
                    this.sendError(a, d, e.type, e.reason);
                }
            } else {
                this.logger.severe("Ignoring request, requestId is not an integer: " + d);
            }
    };

    /**
     * media state
     *
     * @method mediaState
     * @param mediaManager
     * @return {*}
     * @for fling.receiver
     * @private
     */
    var mediaState = function (mediaManager) {
        if (!mediaManager.mediaInformation){
            return "IDLE";   
        }
        if (mediaManager.media) {
            var b = mediaManager.media.getState();
            if("PLAYING" == b && mediaManager.isPlayerBuffering){
                return "BUFFERING";
            }else{
                return b;
            }
        }
        //当为暂停状态
        if(mediaManager.mediaElement.paused){
            //当视频/音频没有播放完毕
            if(mediaManager.mediaElement.duration && (mediaManager.mediaElement.currentTime || 0 == mediaManager.mediaElement.currentTime) && mediaManager.mediaElement.duration != mediaManager.mediaElement.currentTime){
                //当为“加载完成立即播放状态”并且当前时间等于缓冲完成时间 todo
                if(mediaManager.mediaElement.currentTime == mediaManager.loadTime && mediaManager.mediaElement.autoplay){
                    return "BUFFERING";
                }else{
                    return "PAUSED";
                }
                    
            }else{ 
                return "IDLE";
            }
        }else {
             if(mediaManager.isPlayerBuffering){
                return "BUFFERING";
             }else{
                return "PLAYING";
             }
        }
    };

    /**
     * get media status
     *
     * @method getMediaStatus
     * @param mediaManager
     * @param b
     * @param c
     * @return {{type: string}}
     * @for fling.receiver
     * @private
     */
    var getMediaStatus = function (mediaManager, b, c) {
        var d = {
            type: "MEDIA_STATUS"
        };
        if (!mediaManager.mediaInformation && !mediaManager.oMediaInformation){
            d.status = [];
            return d;  
        } 
        var e = mediaManager.media ? mediaManager.media.getVolume() : {
            level: mediaManager.mediaElement.volume,
            muted: mediaManager.mediaElement.muted
        }, e = {
            mediaSessionId: mediaManager.mediaSessionId,
            playbackRate: mediaManager.playbackRate,
            playerState: mediaState(mediaManager),
            currentTime: mediaManager.media ? mediaManager.media.getCurrentTimeSec() : mediaManager.mediaElement.currentTime,
            supportedMediaCommands: mediaManager.supportedMediaCommands,
            volume: e
        };

        if(b){
            e.media = mediaManager.mediaInformation || mediaManager.oMediaInformation || void 0;
        }
        if(!mediaManager.mediaInformation){
            mediaManager.oMediaInformation = null;
        }
        if("IDLE" == e.playerState){
            if(mediaManager.idleReason){
                e.idleReason = mediaManager.idleReason;
            }
        } else{
            mediaManager.idleReason = null;  
        } 
        if(c !=undefined){
            e.customData = c;
        }

        if(mediaManager.customizedStatusCallback){
            var mediaStatus = mediaManager.customizedStatusCallback(e);
            if(null == mediaStatus){
                d = null;
            }else{
                d.status = [mediaStatus];
            }
            mediaStatus = null;
        }else{ 
            d.status = [e];
        }
        return d;
    };

    /**
     * set media status sender time
     *
     * @method setMediaStatusSenderTime
     * @param mediaManager
     * @for fling.receiver
     * @private
     */
    var setMediaStatusSenderTime = function (mediaManager) {
        if(mediaManager.mediaElement){
            mediaManager.currentTime = mediaManager.mediaElement.currentTime;
            mediaManager.mediaStatusSenderCurrentTime = mediaManager.mediaElement.currentTime;
            mediaManager.mediaStatusSenderTime = Date.now();
        }
    };

    /**
     * buff state
     *
     * @method bufferState
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.bufferState = function () {
        goog.Timer.callOnce(goog.bind(this.bufferState, this), 1000);
        //非暂停并且非空闲
        if ("IDLE" != mediaState(this) && "PAUSED" != mediaState(this)) {
            var a = this.currentTime;

            this.currentTime = this.media ? this.media.getCurrentTimeSec() : this.mediaElement.currentTime;

            var b = this.isPlayerBuffering;
            this.isPlayerBuffering = 100 > 1000 * (this.currentTime - a);
            
            if(b !=this.isPlayerBuffering) {
                this.logger.finer("Buffering state changed, isPlayerBuffering: " + this.isPlayerBuffering + " old time: " + a + " current time: " + this.currentTime);
                this.broadcastStatus(false);
            }else{
                if(!this.isPlayerBuffering){
                    if(a = 1000 * (this.currentTime - this.mediaStatusSenderCurrentTime) - (Date.now() - this.mediaStatusSenderTime), 1000 < a || -1000 > a){
                        this.logger.finer("Time drifted: " + a);
                        this.broadcastStatus(false);
                    }
                }
            }
        }
    };

    /**
     * sends a media status message to all senders (broadcast). Applications can use it when they have a custom state change. It will call fling.receiver.MediaManager.prototype.customizedStatusCallback so applications can customize the status message.
     *
     * @method broadcastStatus
     * @param a
     * @param b
     * @param c
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.broadcastStatus = function (a, b, c) {
        if(this.mediaElement || this.media){
            this.logger.finer("Sending broadcast status message");
            a = getMediaStatus(this, a, c);
            if(null != a){
                a.requestId = b || 0;
                this.flingMessageBus.broadcast(a);
                setMediaStatusSenderTime(this);
            }
            
        }else{
            this.logger.severe("Not sending broadcast status message, state is invalid")
        }
    };

    /**
     * Sets the IDLE reason. This allows applications that want to force the IDLE state to indicate the reason that made the player going to IDLE state (a custom error, for example). The idle reason will be sent in the next status message. NOTE: Most applications do not need to set this value, it is only needed if they want to make the player go to IDLE in special circumstances and the default idleReason does not reflect their intended behavior.
     *
     * @method setIdleReason
     * @param idleReason The reason to be in the IDLE state.
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.setIdleReason = function (idleReason) {
        this.logger.finer("Setting IDLE reason: " + idleReason);
        this.idleReason = idleReason
    };

    /**
     * Sends an error to a specific sender.
     *
     * @method sendError
     * @param senderId
     * @param requestId The sender ID.
     * @param type
     * @param opt_reason
     * @param opt_customData
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.sendError = function (senderId, requestId, type, opt_reason, opt_customData) {
        this.logger.info("Sending error message to " + senderId);
        var f = {};
        f.requestId = requestId;
        f.type = type;
        opt_reason && (f.reason = opt_reason);
        opt_customData && (f.customData = opt_customData);
        this.flingMessageBus.send(senderId, f)
    };

    /**
     * Sends a media status message to a specific sender.
     *
     * @method sendStatus
     * @param senderId
     * @param requestId
     * @param includeMedia
     * @param opt_customData
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.sendStatus = function (senderId, requestId, includeMedia, opt_customData) {
        if(this.mediaElement || this.media){
            this.logger.finer("Sending status message to " + senderId);
            includeMedia = getMediaStatus(this, includeMedia, opt_customData);
            if(null != includeMedia){
                includeMedia.requestId = requestId;
                this.flingMessageBus.send(senderId, includeMedia);
                setMediaStatusSenderTime(this);
            }
        }else{
            this.logger.severe("State is invalid"), 
            this.sendError(senderId, requestId, "INVALID_PLAYER_STATE", null, opt_customData);
        }
    };

    /**
     * The application developer can override this method to customize the media status that will be send to the senders (this method will be called before the media status is sent). By providing this method application developers can, for example, add custom data to the media status. The current media status will be provided as a parameter and the method should return the application-modified current status. The default behavior is to return the incoming media status. If the method returns null the media status message will not be sent (developers should be aware that if the media status is a response to a sender status request the sender will expect a response so this method should only return null it if the developer is also overriding onGetStatus).May be null.
     *
     * @method customizedStatusCallback
     * @param mediaStatus
     * @return {*}
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.customizedStatusCallback = function (mediaStatus) {
        return mediaStatus;
    };

    /**
     * If provided, it processes the load event. The default behavior is to set the src and autoplay properties of the media element and call its load method. If provided, the currentTime property will be modified when the 'loadedmetadata' event is fired (in onMetadataLoaded) as it can only be set when the media element duration property has been set. If this method is overriden, the application developer may need to handle sendLoadError, sendLoadComplete and onMetadataLoaded. Please read the documentation of those APIs.May be null.
     *
     * @method onLoad
     * @param event
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onLoad = function (event) {
        var b = event.data;
        if(this.media){
            if(b.media && b.media.contentId){
                this.media.load(b.media.contentId, b.autoplay, b.currentTime);
            }
        }else{
            this.mediaElement.autoplay = false;
            if(b.media && event.data.media.contentId){
                this.mediaElement.src = b.media.contentId;
            }
            this.mediaElement.autoplay = void 0 != b.autoplay ? b.autoplay : true;
            this.mediaElement.load()
        }
    };

    /**
     * Associates a new media element or Player to the media manager.
     *
     * @method setMediaElement
     * @param mediaElement {*} The DOM media element (video/audio) or a player that implements the fling.receiver.media.Player interface. Must not be null.
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.setMediaElement = function (mediaElement) {
        if(mediaElement.getState){
            if(this.mediaElement){
                unRegisterMediaElement(this); 
                this.mediaElement = null;
            }
            if(this.media != mediaElement){
                unRegisterMediaElement(this);
                this.media = mediaElement;
                registerMediaElement(this);
            }
        }else{
            if(this.media){
                unRegisterMediaElement(this);
                this.media = null;
            }
            if(this.mediaElement != mediaElement){
                unRegisterMediaElement(this);
                this.mediaElement = mediaElement;
                registerMediaElement(this);
            }
        }
    };

    /**
     * register media element
     *
     * @method registerMediaElement
     * @param mediaManager
     * @private
     * @for fling.receiver
     */
    var registerMediaElement = function (mediaManager) {
        if(mediaManager.media){
            mediaManager.media.registerErrorCallback(mediaManager.loadMetadataError.bind(mediaManager)); 
            mediaManager.media.registerEndedCallback(mediaManager.ended.bind(mediaManager)); 
            mediaManager.media.registerLoadCallback(mediaManager.loadMetadata.bind(mediaManager));
        }else{
            goog.events.listen(mediaManager.mediaElement, "loadedmetadata", mediaManager.loadMetadata, false, mediaManager);
            goog.events.listen(mediaManager.mediaElement, "error", mediaManager.loadMetadataError, false, mediaManager); 
            goog.events.listen(mediaManager.mediaElement, "ended", mediaManager.ended, false, mediaManager);
        }
    };

    /**
     * unRegister media element
     *
     * @method unRegisterMediaElement
     * @param mediaManager
     * @private
     * @for fling.receiver
     */
    var unRegisterMediaElement = function (mediaManager) {
        if(mediaManager.media){
            mediaManager.media.unregisterErrorCallback(); 
            mediaManager.media.unregisterEndedCallback();
            mediaManager.media.unregisterLoadCallback();
        }else{
            goog.events.unlisten(mediaManager.mediaElement, "loadedmetadata", mediaManager.loadMetadata, false, mediaManager); 
            goog.events.unlisten(mediaManager.mediaElement, "error", mediaManager.loadMetadataError, false, mediaManager); 
            goog.events.unlisten(mediaManager.mediaElement, "ended", mediaManager.ended, false, mediaManager);
        }
    };

    /**
     * load meta data
     *
     * @method loadMetadata
     * @private
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.loadMetadata = function () {
        if (this.loadInfo){
            this.logger.info("Metadata loaded");

            if (this.mediaInformation) {
                this.mediaInformation.duration =
                this.media ? this.media.getDurationSec() : this.mediaElement.duration;
            }

            this.isPlayerBuffering = true;
            if (this.onMetadataLoaded) {
                this.onMetadataLoaded(this.loadInfo);
            }else{
                this.loadInfo = null;
            } 
        }
    };

    /**
     * Called when load has completed, it can be overridden to handle application specific action. The default behavior is to set the currentTime property of the media element (if it was provided in the LOAD request), then call sendLoadComplete.May be null.
     *
     * @method onMetadataLoaded
     * @param a
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onMetadataLoaded = function (a) {
        if (a.message.currentTime && this.mediaElement) {
            this.mediaElement.currentTime = a.message.currentTime;
        };
        this.sendLoadComplete();
    };

    /**
     * Called when load has had an error, it can be overridden to handle application specific logic. The default behavior is to call resetMediaElement with idle reason ERROR and sendLoadError with error type LOAD_FAILED.May be null.
     *
     * @method loadMetadataError
     * @param a
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.loadMetadataError = function (a) {
        if (this.loadInfo) {
            this.logger.severe("Load metadata error");
            if (this.onLoadMetadataError) {
                this.onLoadMetadataError(this.loadInfo);
            } else {
                this.loadInfo = null;
            }
        } else if (this.onError) {
            this.onError(a);
        }
    };

    /**
     * When the application overrides onLoad, it should use this method to trigger an error response to the sender. This is typically due to application-specific verification issues.
     *
     * @method sendLoadError
     * @param opt_errorType
     * @param opt_customData
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.sendLoadError = function (opt_errorType, opt_customData) {
        if(this.loadInfo){
            this.sendError(this.loadInfo.senderId, this.loadInfo.message.requestId, opt_errorType || "LOAD_FAILED", null, opt_customData);
            this.loadInfo = null;
        }else{
            this.logger.severe("Not sending LOAD error as there is no on going LOAD request");
        }
    };

    /**
     * Sends the new status after a LOAD message has been completed successfully. Note: Applications do not normally need to call this API. When the application overrides onLoad, it may need to manually declare that the LOAD request was successful. The default implementaion will send the new status to the sender when the video/audio element raises the 'loadedmetadata' event. The default behavior may not be acceptable in a couple scenarios: 1) When the application does not want to declare LOAD successful until for example 'canPlay' is raised (instead of 'loadedmetadata'). 2) When the application is not actually loading the media element (for example if LOAD is used to load an image).
     *
     * @method sendLoadComplete
     * @param opt_customData
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.sendLoadComplete = function (opt_customData) {
        if(this.loadInfo){
            this.broadcastStatus(!0, this.loadInfo.message.requestId, opt_customData);
            this.loadInfo = null;
        }else{
            this.logger.severe("Not sending status as there is no on going LOAD request");
        }
    };

    /**
     * Called when there is an error not triggered by a LOAD request. The default behavior is to call ResetMediaElement.May be null.
     *
     * @method onError
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onError = function () {
        this.resetMediaElement("ERROR");
    };

    /**
     * Called when load has had an error, it can be overridden to handle application specific logic. The default behavior is to call resetMediaElement with idle reason ERROR and sendLoadError with error type LOAD_FAILED.May be null.
     * @method onLoadMetadataError
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onLoadMetadataError = function () {
        this.resetMediaElement("ERROR", false);
        this.sendLoadError("LOAD_FAILED");
    };

    /**
     * Called when the media ends. The default behavior is to call ResetMediaElement with idle reason FINISHED.May be null.
     *
     * @method ended
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.ended = function () {
        if (this.onEnded) {
            this.onEnded();
        }
    };

    /**
     * Called when the media ends. The default behavior is to call ResetMediaElement with idle reason FINISHED.May be null.
     *
     * @method onEnded
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onEnded = function () {
        this.resetMediaElement("FINISHED");
    };

    /**
     * Processes the get status event.May be null.
     * @method onGetStatus
     * @param event
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onGetStatus = function (event) {
        this.logger.finer("onGetStatus");
        this.sendStatus(event.senderId, event.data.requestId, !0)
    };

    /**
     * Processes the play event. The default behavior is to call the media element's play method and broadcast the status providing the incoming requestId.
     *
     * @method onPlay
     * @param event
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onPlay = function (event) {
        this.logger.finer("onPlay");
        this.media ? this.media.play() : this.mediaElement.play();
        this.broadcastStatus(!1, event.data.requestId)
    };

    /**
     * Processes the seek event. The default behavior is to call the media element's play or pause methods (only if required based on the current state and the resume state value of the request) and broadcast the status providing the incoming requestId.
     *
     * @method onSeek
     * @param event
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onSeek = function (event) {
        var a = event.data;
        this.logger.finer("onSeek: " + JSON.stringify(a));
        if(this.media){
            this.media.seek(a.currentTime, a.resumeState);
            if("PAUSED" != this.media.getState()){
                this.isPlayerBuffering = true;
            }
        }else{
            if(this.mediaElement.currentTime = a.currentTime, "PLAYBACK_START" == a.resumeState && this.mediaElement.paused){
                this.mediaElement.play();
            }else{
                "PLAYBACK_PAUSE" != a.resumeState || this.mediaElement.paused || this.mediaElement.pause();
                this.mediaElement.paused || (this.isPlayerBuffering = !0);
            }
        }
        this.broadcastStatus(!1, a.requestId)
    };

    /**
     * Processes the stop event. The default behavior is to call resetMediaElement, with idle reason CANCELLED, and broadcast the status providing the incoming requestId.
     *
     * @method onStop
     * @param event
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onStop = function (event) {
        this.resetMediaElement("CANCELLED", true, event.data.requestId)
    };

    /**
     * Resets Media Element to IDLE state. After this call the mediaElement properties will change, paused will be true, currentTime will be zero and the src attribute will be empty. This only needs to be manually called if the developer wants to override the default behavior of onError, onStop or onEnded, for example.
     *
     * @method resetMediaElement
     * @param opt_idleReason
     * @param opt_broadcast
     * @param opt_requestId
     * @param opt_broadcastStatusCustomData
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.resetMediaElement = function (opt_idleReason, opt_broadcast, opt_requestId, opt_broadcastStatusCustomData) {
        var b = (null == opt_broadcast) || opt_broadcast;

        if ((opt_broadcastStatusCustomData || opt_requestId) && !b){
            throw Error("customData and requestId should only be provided in broadcast mode");
        }
        if(this.mediaInformation){
            if(this.media){
                this.media.reset();
            }else{
                this.logger.info("Resetting media element");
                this.mediaElement.removeAttribute("src");
                this.loadTime = 0;
                this.mediaElement.load();
                if(opt_idleReason){
                    this.idleReason = opt_idleReason;
                }
                this.oMediaInformation = this.mediaInformation;
                this.mediaInformation = null;
                if(b){
                    this.broadcastStatus(!1, opt_requestId, opt_broadcastStatusCustomData);
                }
            }
        }else{
            this.logger.info("Nothing to reset, Media is already null");
        }
        b = null;
    };

    /**
     * Processes the pause event. The default behavior is to call the media element's pause method and broadcast the status providing the incoming requestId.
     *
     * @method onPause
     * @param event
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onPause = function (event) {
        if (this.media) {
            this.media.pause()
        } else {
            this.mediaElement.pause();
        }
        this.broadcastStatus(false, event.data.requestId);
    };

    /**
     * Processes the set volume event. The default behavior is to set volume and muted on the media element as required and broadcast the status providing the incoming requestId.
     *
     * @method onSetVolume
     * @param event
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.onSetVolume = function (event) {
        var a = event.data;
        if (this.media) {
            this.media.setVolume(a.volume)
        } else {
            if (void 0 != a.volume.level) {
                this.mediaElement.volume = a.volume.level;
            }
            if (void 0 != a.volume.muted) {
                this.mediaElement.muted = a.volume.muted;
            }
            if (FlingReceiverManager.getInstance().onMediaVolumeChanged) {
                FlingReceiverManager.getInstance().onMediaVolumeChanged(a);
            }
        }
        this.broadcastStatus(false, a.requestId);
    };

    /**
     * dispose internal
     *
     * @method disposeInternal
     * @private
     * @for fling.receiver.MediaManager
     */
    MediaManager.prototype.disposeInternal = function () {
        MediaManager.superClass_.disposeInternal.call(this);
        this.logger.finer("Disposed " + this.getDebugString());
    };

    /**
     * SDK VERSION
     *
     * @property VERSION
     * @type String
     * @default "2.0.0"
     * @static
     * @for fling.receiver
     */
    goog.exportSymbol("fling.receiver.VERSION", "2.0.0");

    goog.exportSymbol("fling.receiver.logger", logger);

    /**
     *
     * @property {Object} LoggerLevel
     * @property {number} LoggerLevel.DEBUG=0
     * @property {number} LoggerLevel.VERBOSE=400
     * @property {number} LoggerLevel.INFO=800
     * @property {number} LoggerLevel.ERROR=1000
     * @property {number} LoggerLevel.NONE=1500
     * @for fling.receiver
     * @static
     */
    goog.exportSymbol("fling.receiver.LoggerLevel", {
        DEBUG: 0,
        VERBOSE: 400,
        INFO: 800,
        ERROR: 1000,
        NONE: 1500});
    goog.exportSymbol("fling.receiver.FlingChannel", FlingChannel);

    /**
     * @property NAMESPACE_PREFIX
     * @type string
     * @default "urn:x-cast:"
     * @for fling.receiver.system
     * @static
     */
    goog.exportSymbol("fling.receiver.system.NAMESPACE_PREFIX", "urn:x-cast:");

    /**
     * @method ApplicationData
     * @for fling.receiver.system
     * @static
     */
    goog.exportSymbol("fling.receiver.system.ApplicationData", function () {
        this.name = "";
        this.id = "";
        this.sessionId = 0;
        this.namespaces = [];
        this.launchingSenderId = "";});

    /**
     * @method Sender
     * @static
     * @for fling.receiver.system
     */
    goog.exportSymbol("fling.receiver.system.Sender", function () {
        this.userAgent = "";
        this.id = "";});
    goog.exportSymbol("fling.receiver.FlingMessageBus", FlingMessageBus);
    goog.exportSymbol("fling.receiver.FlingReceiverManager", FlingReceiverManager);

    /**
     * @property MEDIA_NAMESPACE
     * @type String
     * @default "urn:x-cast:com.google.cast.media"
     * @for fling.receiver.media
     * @static
     */
    goog.exportSymbol("fling.receiver.media.MEDIA_NAMESPACE", "urn:x-cast:com.google.cast.media");


    /**
     * @property {Object} StreamType
     * @property {String} StreamType.BUFFERED="BUFFERED"
     * @property {String} StreamType.LIVE="LIVE"
     * @property {String} StreamType.NONE="NONE"
     * @for fling.receiver.media
     * @static
     */
    goog.exportSymbol("fling.receiver.media.StreamType", {
        BUFFERED: "BUFFERED",
        LIVE: "LIVE",
        NONE: "NONE"});

    goog.exportSymbol("fling.receiver.media.ErrorType", MediaErrorType);

    /**
     * @property {Object} ErrorReason
     * @property {String} ErrorReason.INVALID_COMMAND="INVALID_COMMAND"
     * @property {String} ErrorReason.INVALID_PARAMS="INVALID_PARAMS"
     * @property {String} ErrorReason.INVALID_MEDIA_SESSION_ID="INVALID_MEDIA_SESSION_ID"
     * @property {String} ErrorReason.DUPLICATE_REQUEST_ID="DUPLICATE_REQUEST_ID"
     * @for fling.receiver.media
     * @static
     */
    goog.exportSymbol("fling.receiver.media.ErrorReason", {
        INVALID_COMMAND: "INVALID_COMMAND",
        INVALID_PARAMS: "INVALID_PARAMS",
        INVALID_MEDIA_SESSION_ID: "INVALID_MEDIA_SESSION_ID",
        DUPLICATE_REQUEST_ID: "DUPLICATE_REQUEST_ID"});

    /**
     * @property {Object} IdleReason
     * @property {String} IdleReason.CANCELLED="CANCELLED"
     * @property {String} IdleReason.INTERRUPTED="INTERRUPTED"
     * @property {String} IdleReason.FINISHED="FINISHED"
     * @property {String} IdleReason.ERROR="ERROR"
     * @for fling.receiver.media
     * @static
     */
    goog.exportSymbol("fling.receiver.media.IdleReason", {
        CANCELLED: "CANCELLED",
        INTERRUPTED: "INTERRUPTED",
        FINISHED: "FINISHED",
        ERROR: "ERROR"});

    /**
     * @property {Object} SeekResumeState
     * @property {String} SeekResumeState.Rb="PLAYBACK_START"
     * @property {String} SeekResumeState.Qb="PLAYBACK_PAUSE"
     * @for fling.receiver.media
     * @static
     */
    goog.exportSymbol("fling.receiver.media.SeekResumeState", {
        Rb: "PLAYBACK_START",
        Qb: "PLAYBACK_PAUSE"});

    /**
     * @property {Object} PlayerState
     * @property {String} PlayerState.IDLE="IDLE"
     * @property {String} PlayerState.PLAYING="PLAYING"
     * @property {String} PlayerState.PAUSED="PAUSED"
     * @property {String} PlayerState.BUFFERING="BUFFERING"
     * @for fling.receiver.media
     * @static
     */
    goog.exportSymbol("fling.receiver.media.PlayerState", {
        IDLE: "IDLE",
        PLAYING: "PLAYING",
        PAUSED: "PAUSED",
        BUFFERING: "BUFFERING"});

    goog.exportSymbol("fling.receiver.media.MediaInformation", MediaInformation);
    goog.exportSymbol("fling.receiver.media.Volume", Volume);
    goog.exportSymbol("fling.receiver.media.MediaStatus", MediaStatus);
    goog.exportSymbol("fling.receiver.media.Command", Command);
    goog.exportSymbol("fling.receiver.MediaManager", MediaManager);
}).call(window);
