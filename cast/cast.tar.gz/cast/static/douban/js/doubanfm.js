// External namespace for cast specific javascript library
var doubanreceiver = window.doubanreceiver || {};

// Anonymous namespace
(function () {
    'use strict';

    DoubanFM.PROTOCOL = "urn:x-cast:com.infthink.cast.doubanfm";

    /**
     * Creates a DoubanFM object with an optional board and attaches a
     * cast.receiver.ChannelHandler, which receives messages from the
     * channel between the sender and receiver.
     * @param {board} opt_board an optional game board.
     * @constructor
     */
    function DoubanFM(fmFrame) {
        this.mFmFrame = fmFrame;

        for (var i = 0; i < 10; i++) {
            console.log("fmFrame" + this.mFmFrame);
        }

        this.castReceiverManager_ = fling.receiver.FlingReceiverManager.getInstance();
        this.castMessageBus_ = this.castReceiverManager_.getFlingMessageBus(DoubanFM.PROTOCOL,
                fling.receiver.FlingMessageBus.MessageType.JSON);
        this.castMessageBus_.onMessage = this.onMessage.bind(this);
        this.castReceiverManager_.onSenderConnected =
        this.onSenderConnected.bind(this);
        this.castReceiverManager_.onSenderDisconnected =
        this.onSenderDisconnected.bind(this);
        this.castReceiverManager_.start();
    }

    // Adds event listening functions to DoubanFM.prototype.
    DoubanFM.prototype = {
        onSenderConnected: function(event) {
        },
        onSenderDisconnected: function(event) {
        },
        /**
         * Message received event; determines event message and command, and
         * choose function to call based on them.
         * @param {event} event the event to be processed.
         */
        onMessage: function (event) {
            console.log('next');

            var message = event.data;
            console.log('********onMessage********' + $("#status").text());
            
            if (message.command == 'play') {
                console.log('next');
                $("iframe").attr('src', 'http://douban.fm/partner/uc');
                $("#status").text("正在收听");
            } else if (message.command == 'stop') {
                console.log('stop');
                $("iframe").attr('src', '');
                $("#status").text("已经停止");
            } else if (message.command == 'next') {
                console.log('next');
                $("iframe").attr('src', 'http://douban.fm/partner/uc');
                $("#status").text("正在收听");
            } else {
                console.log('Invalid message command: ' + message.command);
            }
        }
    };

    // Exposes public functions and APIs
    doubanreceiver.DoubanFM = DoubanFM;
})();
